Config = {}

Config.Core = "QBCore:GetObject"

Config.Locale       				= 'en' 

Config.PoliceJobName				= 'senator' --Change with your police job name

Config.ServiceExtensionOnEscape		= 8

Config.ServiceLocation 				= {x =  -1393.462, y = 6744.086, z = 11.908}

Config.ReleaseLocation				= {x = 427.33, y = -979.51, z = 30.2}

Config.ServiceLocations = {
	{ type = "cleaning", coords = vector3(-1404.575, 6747.662, 11.908) },
	{ type = "cleaning", coords = vector3(-1391.938, 6749.553, 11.908) },
	{ type = "cleaning", coords = vector3(-1386.888, 6741.837, 11.981) },
	{ type = "cleaning", coords = vector3(-1397.76, 6738.289, 11.908) },
	{ type = "cleaning", coords = vector3(-1394.553, 6743.717, 11.908) },
	{ type = "cleaning", coords = vector3(-1396.943, 6751.112, 11.908) },
	{ type = "cleaning", coords = vector3(-1402.301, 6753.478, 11.908) },
	{ type = "cleaning", coords = vector3(-1388.916, 6748.479, 11.908) },
	{ type = "cleaning", coords = vector3(-1391.06, 6743.792, 11.981) }
}

