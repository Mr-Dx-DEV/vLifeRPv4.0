Config = {
    ServerCallbacks = {}, -- Don't edit or change
    AutoDatabaseCreator = true, -- If you are starting the script for the first time, make this true and restart the script, after restarting, make this false otherwise you will get an error.
    CommandPermission = 'god', -- Permission level for add stock (god for QB, admin for ESX)
    TestDriveTime = 30000, -- Seconds 600000
    TeleportBackWhenTestFinishes = true, -- If false destroys the test vehicle's engine and sets it unusable again
    SalesShare = 10, -- The player making the sale receives a share of the entered amount from the sale.
    VehicleShops = {
        {
            Management = {
                Enable = false,
                Job = "cardealer"
            },
            EnableStocks = false,
            AllowedCategories = {"sedans", "sportsclassics", "offroad", "cycles", "motorcycles", "vans", "super", "sports", "coupes", "compacts", "suvs", "muscle"},
          
            Coords = {
                ShowroomVehicles = vector4(-47.2, -1092.42, 26.3, 98.41),
                BoughtVehicles = vector4(-16.45, -1095.21, 26.97, 167.97),
                TestVehicles =vector4(-16.45, -1095.21, 26.97, 167.97),
                SellingPoint = vector3(0.0, 0.0, 0.0)
            },
            Ped = {
                Enable = true,
                Coords = vector4(-31.26, -1097.73, 27.27, 69.93),
                Model = "a_m_y_hasjew_01",
                animDict = "amb@world_human_hang_out_street@female_arms_crossed@idle_a",
                animName = "idle_a"
            },
            ShowroomVehicles = {
                {coords = vector4(-50.67, -1116.44, 25.97, 2.26)},
                {coords = vector4(-53.56, -1116.84, 25.79, 3.36)},
                {coords = vector4(-56.3, -1116.97, 25.66, 1.13)},
                {coords = vector4(-59.18, -1116.89, 26.17, 1.44)},
                {coords = vector4(-61.83, -1117.06, 25.84, 2.23)}
            },
            Blip = { -- https://docs.fivem.net/docs/game-references/blips/
                Enable = true,
                coords = vector3(-57.13, -1099.05, 26.42),
                sprite = 326,
                color = 0,
                scale = 0.8,
                text = "Dealership"
            },
            Interaction = {
                Target = {
                    Enable = true,
                    Distance = 2.0,
                    Label = "Open Showroom",
                    Icon = "fa-solid fa-car",
                    Label2 = "Open Management",
                    Icon2 = "fa-solid fa-car"
                },
                Text = {
                    Enable = false,
                    Distance = 3.0,
                    Label = "[E] Open Showroom | [G] Open Management"
                },
                DrawText = {
                    Enable = false,
                    Distance = 3.0,
                    Show = function()
                        exports["qb-core"]:DrawText("Contact", "left")
                    end,
                    Hide = function()
                        exports["qb-core"]:HideText()
                    end
                }
            }
        }
        -- {
        --     Management = {
        --         Enable = false,
        --         Job = "police"
        --     },
        --     EnableStocks = false,
        --     AllowedCategories = {"emergency", "heavy", "PEDM", "interceptor", "standard", "polbike"},
        --     Coords = {
        --         ShowroomVehicles = vector4(-2415.552, 3290.924, 32.83, 335.517),
        --         BoughtVehicles = vector4(431.267, -985.242, 25.7, 174.734),
        --         TestVehicles =vector4(431.267, -985.242, 25.7, 174.734),
        --         SellingPoint = vector3(0.0, 0.0, 0.0)
        --     },
        --     Ped = {
        --         Enable = true,
        --         Coords = vector4(441.413, -975.305, 25.7, 181.586),
        --         Model = "s_m_y_blackops_01",
        --         animDict = "amb@world_human_hang_out_street@female_arms_crossed@idle_a",
        --         animName = "idle_a"
        --     },
        --     ShowroomVehicles = {
        --         {coords = vector4(-50.67, -1116.44, 25.97, 2.26)},
        --         {coords = vector4(-53.56, -1116.84, 25.79, 3.36)},
        --         {coords = vector4(-56.3, -1116.97, 25.66, 1.13)},
        --         {coords = vector4(-59.18, -1116.89, 26.17, 1.44)},
        --         {coords = vector4(-61.83, -1117.06, 25.84, 2.23)}
        --     },
        --     Blip = { -- https://docs.fivem.net/docs/game-references/blips/
        --         Enable = false,
        --         coords = vector3(-57.13, -1099.05, 26.42),
        --         sprite = 326,
        --         color = 0,
        --         scale = 0.8,
        --         text = "Police Dealership"
        --     },
        --     Interaction = {
        --         Target = {
        --             Enable = true,
        --             Distance = 2.0,
        --             Label = "Open Showroom",
        --             Icon = "fa-solid fa-car",
        --             Label2 = "Open Management",
        --             Icon2 = "fa-solid fa-car"
        --         },
        --         Text = {
        --             Enable = false,
        --             Distance = 3.0,
        --             Label = "[E] Open Showroom | [G] Open Management"
        --         },
        --         DrawText = {
        --             Enable = false,
        --             Distance = 3.0,
        --             Show = function()
        --                 exports["qb-core"]:DrawText("Contact", "left")
        --             end,
        --             Hide = function()
        --                 exports["qb-core"]:HideText()
        --             end
        --         }
        --     }
        -- }
    }
}

-- Fuel Function
function Config.SetFuel(vehicle, fuel)
    exports["cdn-fuel"]:SetFuel(vehicle, fuel)
end

-- Key Function
function Config.GiveKey(plate)
    TriggerEvent('vehiclekeys:client:SetOwner', plate)
end

-- HUD Function
function Config.HUD(state)
   -- TriggerEvent('esx:toggleHUD', state)
    TriggerEvent('qb-hud:display', state)
end

-- Management Function
function Config.AddManagementMoney(job, amount)
    exports['qb-management']:AddMoney(job, amount)
end