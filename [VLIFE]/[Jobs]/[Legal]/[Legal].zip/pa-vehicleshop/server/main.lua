-- Function to send a message to Discord via webhook
function sendToDiscord(webhookUrl, title, message, color)
    local embed = {
        {
            ["title"] = title,
            ["description"] = message,
            ["color"] = color
        }
    }

    PerformHttpRequest(webhookUrl, function(err, text, headers) end, 'POST', json.encode({username = "Vehicle Shop Logs", embeds = embed}), { ['Content-Type'] = 'application/json' })
end

-- Server event to handle setting death status
RegisterServerEvent('hospital:server:SetDeathStatus')
AddEventHandler('hospital:server:SetDeathStatus', function(isDead)
    if isDead then
        TriggerClientEvent('pa-dealership:close:client', source)
    end
end)

-- Callback to get vehicle stock data
CreateCallback('pa-vehicleshop:getVehStock:server', function(source, cb, model)
    local stockData = MySQL.query.await('SELECT * FROM pa_vehicleshop_stocks')
    local stockTable = {}
    if next(stockData) ~= nil then
        for k, v in pairs(stockData) do
            table.insert(stockTable, {
                model = v.model,
                stock = v.stock
            })
        end
        cb(stockTable)
    else
        cb(0)
    end
end)

-- Helper function to check player's money
function checkPlayerMoney(player, type, amount)
    local playerMoney = GetPlayerMoney(player, type)
    if playerMoney >= amount then
        return true
    else
        return false
    end
end

-- Event to handle buying a vehicle
RegisterNetEvent('pa-vehicleshop:buyVehicle:server', function(type, vehicle, price, dealershipId, sender, job)
    local src = source
    local player = GetPlayer(src)
    local sender = tonumber(sender)
    local target = GetPlayer(sender)
    local hasEnoughMoney = checkPlayerMoney(src, type, price)
    
    if not hasEnoughMoney then
        Notify(src, "You don't have enough money.", 7500, "error")
        sendToDiscord("https://discord.com/api/webhooks/1280830256374091918/rNCxsj-Q6jbfRlUokGP15cvvZZVevzDJIFGfdU-FgfSgrD0OOYTvoW-HhDQS-xxPr3U_", "Vehicle Purchase Failed", "Player " .. GetPlayerName(src) .. " tried to buy a vehicle but didn't have enough money.", 15158332)
        return
    end
    
    if Config.VehicleShops[dealershipId].Management.Enable then
        Config.AddManagementMoney(job, price)
    end
    
    if target then
        local targetMoney = price * Config.SalesShare / 100
        AddMoney(sender, "bank", targetMoney, "Vehicle sales share")
        Notify(sender, "You earned $" .. targetMoney .. " - " .. vehicle .. ".", 7500, "success")
    end
    
    local plate = GeneratePlate()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        MySQL.insert('INSERT INTO player_vehicles (license, citizenid, vehicle, hash, mods, plate, garage, state) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', {
            player.PlayerData.license,
            player.PlayerData.citizenid,
            vehicle,
            GetHashKey(vehicle),
            '{}',
            plate,
            'pillboxgarage',
            0
        })
    else
        MySQL.insert('INSERT INTO owned_vehicles (owner, plate, vehicle, logs, garage, mods, fuel, engine, body) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', {
            player.identifier,
            plate,
            json.encode({model = joaat(vehicle), plate = plate}),
            '{}',
            'motelgarage',
            vehMods,
            100,
            1000,
            1000
        })
    end
    
    RemoveMoney(src, type, price, "vehicle-bought-in-showroom")
    TriggerClientEvent('pa-vehicleshop:buyVehicle:client', src, vehicle, plate, dealershipId)
    
    local vehicleData = MySQL.query.await('SELECT * FROM pa_vehicleshop_stocks WHERE model = ?', {vehicle})
    if Config.VehicleShops[dealershipId].EnableStocks then
        if vehicleData[1] then
            local stock = vehicleData[1].stock - 1
            MySQL.update('UPDATE pa_vehicleshop_stocks SET stock = ? WHERE model = ?', {stock, vehicle})
        end
    end
    
    sendToDiscord("https://discord.com/api/webhooks/1280830256374091918/rNCxsj-Q6jbfRlUokGP15cvvZZVevzDJIFGfdU-FgfSgrD0OOYTvoW-HhDQS-xxPr3U_", "Vehicle Purchase Successful", "Player " .. GetPlayerName(src) .. " bought a vehicle: " .. vehicle .. " for $" .. price .. ".", 3066993)
end)

-- Function to generate random plate numbers
function GeneratePlate()
    local plate = RandomInt(1) .. RandomStr(2) .. RandomInt(3) .. RandomStr(2)
    local result = MySQL.scalar.await('SELECT plate FROM ' .. Table .. ' WHERE plate = ?', {plate})
    if result then
        return GeneratePlate()
    else
        return plate:upper()
    end
end

-- Charset tables for generating random strings and numbers
local StringCharset = {}
local NumberCharset = {}

for i = 48, 57 do NumberCharset[#NumberCharset + 1] = string.char(i) end
for i = 65, 90 do StringCharset[#StringCharset + 1] = string.char(i) end
for i = 97, 122 do StringCharset[#StringCharset + 1] = string.char(i) end

function RandomStr(length)
    if length <= 0 then return '' end
    return RandomStr(length - 1) .. StringCharset[math.random(1, #StringCharset)]
end

function RandomInt(length)
    if length <= 0 then return '' end
    return RandomInt(length - 1) .. NumberCharset[math.random(1, #NumberCharset)]
end

-- Database auto-creator for vehicle shops
if Config.AutoDatabaseCreator then
    Citizen.CreateThread(function()
        while CoreReady == false do Citizen.Wait(0) end
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS `pa_vehicleshop_stocks` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `model` varchar(50) NOT NULL DEFAULT '0',
            `stock` int(11) NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`)
            ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;]])
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS `pa_vehicleshop_showroom_vehicles` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `dealershipId` int(11) DEFAULT NULL,
            `data` longtext NOT NULL,
            PRIMARY KEY (`id`)
            ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;]])
    end)
end

-- Command registration for adding vehicle stock
Citizen.CreateThread(function()
    while CoreReady == false do Citizen.Wait(0) end
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Commands.Add('addvehiclestock', Lang:t("commands.add_vehicle_stock"), {}, false, function(source, args)
            if args[1] and tonumber(args[2]) then
                addVehicleStock(args[1], tonumber(args[2]))
            end
        end, Config.CommandPermission)
    elseif CoreName == "es_extended" then
        Core.RegisterCommand('addvehiclestock', Config.CommandPermission, function(xPlayer, args, showError)
            if args.vehname and args.stock then
                addVehicleStock(args.vehname, tonumber(args.stock))
            end
        end, false, {help = Lang:t("commands.add_vehicle_stock"), validate = true, arguments = {{name = "vehname", help = "Vehicle Model", type = "string"}, {name = "stock", help = "Stock Number", type = "number"}}})
    end
end)

-- Function to add vehicle stock
function addVehicleStock(model, stockNum)
    local vehicleData = MySQL.query.await('SELECT * FROM pa_vehicleshop_stocks WHERE model = ?', {model})
    if vehicleData[1] then
        local stock = vehicleData[1].stock + stockNum
        MySQL.update('UPDATE pa_vehicleshop_stocks SET stock = ? WHERE model = ?', {stock, model})
    else
        MySQL.insert('INSERT INTO pa_vehicleshop_stocks (model, stock) VALUES (:model, :stock)', {
            model = model,
            stock = stockNum
        })
    end
end

-- Event handling for test vehicles
local testVehicles = {}
RegisterNetEvent('pa-vehicleshop:startTest:server')
AddEventHandler('pa-vehicleshop:startTest:server', function(netId)
    testVehicles[netId] = {
        playerId = source
    }
end)

RegisterNetEvent('pa-vehicleshop:finishTest:server')
AddEventHandler('pa-vehicleshop:finishTest:server', function(netId)
    if testVehicles[netId] then
        testVehicles[netId] = nil
    end
end)

-- Entity removal event handling
AddEventHandler('entityRemoved', function(entity)
    local netId = NetworkGetNetworkIdFromEntity(entity)
    if testVehicles[netId] then
        TriggerClientEvent('pa-vehicleshop:finishTest:client', testVehicles[netId].playerId)
        testVehicles[netId] = nil
    end
end)

-- Event to update showroom vehicles data
RegisterNetEvent('pa-vehicleshop:updateShowroomVehicles:server', function(dealershipId, data)
    local src = source
    local showroomData = MySQL.query.await('SELECT * FROM pa_vehicleshop_showroom_vehicles WHERE dealershipId = ?', {dealershipId})
    if showroomData[1] then
        MySQL.update('UPDATE pa_vehicleshop_showroom_vehicles SET data = ? WHERE dealershipId = ?', {json.encode(data), dealershipId})
    else
        MySQL.insert('INSERT INTO pa_vehicleshop_showroom_vehicles (dealershipId, data) VALUES (?, ?)', {dealershipId, json.encode(data)})
    end
end)

-- Callback to get showroom data
CreateCallback('pa-vehicleshop:getShowroomData:server', function(source, cb)
    local showroomTable = {}
    local showroomDatas = MySQL.query.await('SELECT * FROM pa_vehicleshop_showroom_vehicles')
    if showroomDatas[1] then
        if next(showroomDatas) and next(showroomDatas) ~= nil then
            for k, v in pairs(showroomDatas) do
                for a, b in pairs(json.decode(v.data)) do
                    table.insert(showroomTable, {
                        dealershipId = v.dealershipId,
                        coords = vector4(b.coords.x, b.coords.y, b.coords.z, b.coords.w),
                        vehicleModel = b.vehicleModel,
                        spotId = b.spotId
                    })
                end
            end
        end
    end
    cb(showroomTable)
end)

-- Send payment request event
RegisterNetEvent('pa-vehicleshop:sendRequestText:server', function(sender, target, price, model, dealershipId)
    TriggerClientEvent('pa-vehicleshop:sendRequestText:client', target, sender, price, model, dealershipId)
end)

-- Handle declined payments
RegisterNetEvent('pa-vehicleshop:declinePayment:server', function(sender)
    Notify(sender, "Request declined.", 7500, "error")
    sendToDiscord("https://discord.com/api/webhooks/1280830256374091918/rNCxsj-Q6jbfRlUokGP15cvvZZVevzDJIFGfdU-FgfSgrD0OOYTvoW-HhDQS-xxPr3U_", "Payment Declined", "Player " .. GetPlayerName(sender) .. " declined a payment request.", 15158332)
end)
