const formatter = new Intl.NumberFormat('en-US');
showroomOpen = false;
showroomMenuOpen = false;
selectedCategory = null;
vehicles = {};
currentVeh = null;
currentColor = null;
currentVehLabel = null;
currentPrice = null;
currentCategoryVehs = [];
currentCategoryVehs2 = [];
currentPaymentType = null;
selectedSpot = null;
selectedSpotVehicle = null;
showroomVehicles = [];
currentDealershipId = null;
sellMenuOpen = false;
managementState = false;
window.addEventListener('message', function(event) {
    ed = event.data;
    if (ed.action === "openDealership") {
		currentDealershipId = ed.dealershipId;
		managementState = ed.managementState;
		document.getElementById("MDSPaymentDivBottomPayButton1").style.display = "none";
		document.getElementById("MDSPaymentDivBottomPayButton2").style.display = "none";
		currentCategoryVehs = [];
		currentCategoryVehs2 = [];
		currentVeh = null;
		selectedCategory = null;
		showroomOpen = true;
		document.getElementById("mainDiv").style.display = "flex";
		document.getElementById("mainDivBottomCenterDiv").innerHTML="";
		vehicles = ed.vehicles;
		document.getElementById("MDSCategoriesDivInside").innerHTML="";
		ed.categories.forEach(function(categoryData, index) {
			let size = 3.5;
			if (categoryData.name === "cycles" || categoryData.name === "motorcycles") {
				size = 2.5;
			}
			var categoryHTML = `<div class="MDSCategoryDiv" id="MDSCategoryDiv-${categoryData.name}" onclick="clFunc('showCategoryVehicles', '${categoryData.name}')"><img src="files/${categoryData.name}.png" style="width: ${size}vw;"><span>${categoryData.label}</span></div>`;
			appendHtml(document.getElementById("MDSCategoriesDivInside"), categoryHTML);
			if (!selectedCategory) {
				selectedCategory = categoryData.name;
				clFunc('showCategoryVehicles', selectedCategory)
			}
		});
	} else if (ed.action === "closeUI") {
		showroomOpen = false;
		document.getElementById("mainDiv").style.display = "none";
		document.getElementById("confirmDiv").style.display = "none";
	} else if (ed.action === "updateCarInformations") {
		// Acceleration
		document.getElementById("MDSSpecificationDivTopRight-acceleration").innerHTML=parseInt(ed.acceleration);
		document.getElementById("MDSSpecificationDivBottomInside-acceleration").style.width = ed.acceleration;
		document.getElementById("MDSSpecificationDivBottomLine-acceleration").style.left = ed.acceleration;
		// Speed
		document.getElementById("MDSSpecificationDivTopRight-speed").innerHTML=parseInt(ed.speed);
		document.getElementById("MDSSpecificationDivBottomInside-speed").style.width = ed.speed / 2;
		document.getElementById("MDSSpecificationDivBottomLine-speed").style.left = ed.speed / 2;
		// Braking
		let brake = ed.brake * 100;
		if (brake >= 100) {
			document.getElementById("MDSSpecificationDivTopRight-brake").innerHTML=brake.toFixed(0);
			document.getElementById("MDSSpecificationDivBottomInside-brake").style.width = "99%";
			document.getElementById("MDSSpecificationDivBottomLine-brake").style.left = "99%";
		} else {
			document.getElementById("MDSSpecificationDivTopRight-brake").innerHTML=brake.toFixed(0);
			document.getElementById("MDSSpecificationDivBottomInside-brake").style.width = brake + "%";
			document.getElementById("MDSSpecificationDivBottomLine-brake").style.left = brake + "%";
		}
	} else if (ed.action === "startTestTimer") {
		$("#testDriveDivProgbar").stop().css({width: '100%'}).animate({
			width: "0%",
		}, ed.testDriveTime, 'linear', function() {});
		document.getElementById("testDriveDiv").style.display = "flex";
		var timer = ed.testDriveTime / 1000, minutes, seconds;
		timerInt = setInterval(function() {
			minutes = parseInt(timer / 60, 10);
			seconds = parseInt(timer % 60, 10);
			minutes = minutes < 10 ? "0" + minutes : minutes;
			seconds = seconds < 10 ? "0" + seconds : seconds;
			document.getElementById("testDriveTimer").innerHTML=minutes.toString() + ":" + seconds.toString();
			if (--timer < 0) {
				clearInterval(timerInt);
				document.getElementById("testDriveTimer").innerHTML="00:00";
				document.getElementById("testDriveDiv").style.display = "none";
				var xhr = new XMLHttpRequest();
				xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
				xhr.setRequestHeader('Content-Type', 'application/json');
				xhr.send(JSON.stringify({action: "finishTest"}));
			}
		}, 1000);
	} else if (ed.action === "stopTestTimer") {
		clearInterval(timerInt);
		document.getElementById("testDriveTimer").innerHTML="00:00";
		document.getElementById("testDriveDiv").style.display = "none";
	} if (ed.action === "openShowroomMenu") {
		currentDealershipId = ed.dealershipId;
		document.getElementById("showroomDivTopInput").value="";
		document.getElementById("showroomDiv").style.display = "flex";
		showroomMenuOpen = true;
		selectedSpotVehicle = null;
		selectedSpot = null;
		// Spots
		document.getElementById("showroomDivBottomLeft").innerHTML="";
		ed.spots.forEach(function(spotData, index) {
			var spotHTML = `<div class="showroomDivBottomLeftDiv" id="showroomDivBottomLeftDiv-${spotData.id}" onclick="clFunc('selectSpot', '${spotData.id}')"><i class="fas fa-street-view"></i><span>Spot #${spotData.id}</span></div>`;
			appendHtml(document.getElementById("showroomDivBottomLeft"), spotHTML);
			if (!selectedSpot) {
				clFunc('selectSpot', spotData.id)
			}
		});
		// Vehicles
		document.getElementById("showroomDivBottomRight").innerHTML="";
		ed.vehicles.forEach(function(vehicleData, index) {
			var spotVehicleHTML = `
			<div id="showroomDivBottomRightDiv">
				<div id="showroomDivBottomRightDivTop">
				<div id="showroomDivBottomRightDivTopTextDiv"><span>${vehicleData.name}</span></div>
				<img src="https://docs.fivem.net/vehicles/${vehicleData.model}.webp">
				</div>
				<div class="showroomDivBottomRightDivBottom" id="showroomDivBottomRightDivBottom-${vehicleData.model}" onclick="clFunc('selectSpotVehicle', '${vehicleData.model}')"><span>Display</span><div id="showroomDivBottomRightDivBottomChevrons"><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i></div></div>
			</div>`;
			appendHtml(document.getElementById("showroomDivBottomRight"), spotVehicleHTML);
			// if (!selectedSpotVehicle) {
			// 	clFunc('selectSpotVehicle', vehicleData.model)
			// }
		});
		showroomVehicles = [...new Set(ed.vehicles.map((vehicle) => {return vehicle}))];
	} else if (ed.action === "openSellMenu") {
		sellMenuOpen = true;
		currentDealershipId = ed.dealershipId;
		document.getElementById("showroomDivTopInput2").value="";
		document.getElementById("sellVehicleDiv").style.display = "flex";
		selectedSpotVehicle = null;
		selectedSpot = null;
		document.getElementById("showroomDivBottomRight2").innerHTML="";
		ed.vehicles.forEach(function(vehicleData, index) {
			var spotVehicleHTML2 = `
			<div id="showroomDivBottomRightDiv">
				<div id="showroomDivBottomRightDivTop">
				<div id="showroomDivBottomRightDivTopTextDiv"><span>${vehicleData.name}</span></div>
				<img src="https://docs.fivem.net/vehicles/${vehicleData.model}.webp">
				</div>
				<div class="showroomDivBottomRightDivBottom" id="showroomDivBottomRightDivBottom-${vehicleData.model}" onclick="clFunc('selectSellVehicle', '${vehicleData.model}', '${vehicleData.price}')" style="gap: 0.2vw;"><span>Send Request</span><div id="showroomDivBottomRightDivBottomChevrons"><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i></div></div>
			</div>`;
			appendHtml(document.getElementById("showroomDivBottomRight2"), spotVehicleHTML2);
		});
		showroomVehicles = [...new Set(ed.vehicles.map((vehicle) => {return vehicle}))];
	}
    document.onkeyup = function(data) {
		if (data.which == 27 && showroomOpen) {
			showroomOpen = false;
			showroomMenuOpen = false;
			document.getElementById("showroomDiv").style.display = "none";
			document.getElementById("mainDiv").style.display = "none";
			document.getElementById("confirmDiv").style.display = "none";
			var xhr = new XMLHttpRequest();
			xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.send(JSON.stringify({action: "close", type: "showroom"}));
		}
		if (data.which == 27 && showroomMenuOpen) {
			showroomMenuOpen = false;
			document.getElementById("showroomDiv").style.display = "none";
			var xhr = new XMLHttpRequest();
			xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.send(JSON.stringify({action: "close", type: "showroomEdit", dealershipId: currentDealershipId}));
		}
		if (data.which == 27 && sellMenuOpen) {
			sellMenuOpen = false;
			document.getElementById("sellVehicleDiv").style.display = "none";
			var xhr = new XMLHttpRequest();
			xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.send(JSON.stringify({action: "close", type: "sellMenu"}));
		}
		// if (data.which == 87 && showroomOpen) {
		// 	var xhr = new XMLHttpRequest();
		// 	xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		// 	xhr.setRequestHeader('Content-Type', 'application/json');
		// 	xhr.send(JSON.stringify({action: "camUp"}));
		// }
		// if (data.which == 83 && showroomOpen) {
		// 	var xhr = new XMLHttpRequest();
		// 	xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		// 	xhr.setRequestHeader('Content-Type', 'application/json');
		// 	xhr.send(JSON.stringify({action: "camDown"}));
		// }
		if (data.which == 65 && showroomOpen) {
			var xhr = new XMLHttpRequest();
			xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.send(JSON.stringify({action: "camLeft"}));
		}
		if (data.which == 68 && showroomOpen) {
			var xhr = new XMLHttpRequest();
			xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.send(JSON.stringify({action: "camRight"}));
		}
		if (data.which == 81 && showroomOpen) {
			var xhr = new XMLHttpRequest();
			xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.send(JSON.stringify({action: "zoomOut"}));
		}
		if (data.which == 69 && showroomOpen) {
			var xhr = new XMLHttpRequest();
			xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.send(JSON.stringify({action: "zoomIn"}));
		}
	}
})

function clFunc(name1, name2, name3, name4, name5, name6) {
	if (name1 === "showCategoryVehicles") {
		currentCategoryVehs = [];
		if (selectedCategory) {
			document.getElementById("MDSCategoryDiv-" + selectedCategory).classList.remove("MDSCategoryDivActive");
		}
		currentVeh = null;
		selectedCategory = name2;
		document.getElementById("MDSCategoryDiv-" + name2).classList.add("MDSCategoryDivActive");
		// Insert Vehicles
		document.getElementById("mainDivBottomCenterDiv").innerHTML="";
		vehicles.forEach(function(vehData, index) {
			if (vehData.category === name2) {
				let firstLetter = vehData.model.charAt(0);
				let firstLetterCap = firstLetter.toUpperCase();
				let remainingLetters = vehData.model.slice(1);
				let vLabel = vehData.brand + " " + firstLetterCap + remainingLetters;
				let stockText = "In Stock";
				let stockClass = "MDBCDVehicleDivTopRightSide1";
				if (vehData.stock === 0 || vehData.stock === undefined) {
					stockText = "Out of Stock";
					stockClass = "MDBCDVehicleDivTopRightSide2";
				}
				var vehiclesHTML = `
				<div class="MDBCDVehicleDiv" id="MDBCDVehicleDiv-${vehData.spawncode}" onclick="clFunc('chooseVeh', '${vehData.spawncode}', '${vehData.categoryLabel}', '${vehData.price}', '${vLabel}', '${vehData.stock}')">
					<div id="MDBCDVehicleDivTop">
						<div id="MDBCDVehicleDivTopLeftSide">
							<h4>${vehData.brand} ${vehData.model}</h4>
							<span style="font-family: Gilroy-Regular; color: rgba(255, 255, 255, 0.45); font-size: 0.8vw;">${vehData.categoryLabel}</span>
						</div>
						<div class="MDBCDVehicleDivTopRightSide ${stockClass}"><span>${stockText}</span></div>
					</div>
					<img src="https://docs.fivem.net/vehicles/${vehData.model}.webp" style="width: auto; height: 80px;">
					<div id="MDBCDVehicleDivBottom">
						<div class="MDBCDVehicleDivTopRightSide" style="bottom: 0; color: rgba(144, 255, 215, 0.77); text-shadow: 0px 0px 4.8px rgba(144, 255, 215, 0.55);"><span>$${vehData.price}</span></div>
					</div>
				</div>`;
				appendHtml(document.getElementById("mainDivBottomCenterDiv"), vehiclesHTML);
				if (!currentVeh) {
					currentVeh = vehData.spawncode;
					clFunc('chooseVeh', currentVeh, vehData.categoryLabel, vehData.price, vLabel, vehData.stock)
				}
				currentCategoryVehs.push({
					spawncode: vehData.spawncode,
					brand: vehData.brand,
					model: vehData.model,
					categoryLabel: vehData.categoryLabel,
					price: vehData.price,
					vLabel: vLabel,
					stock: vehData.stock
				});
			}
		});
		currentCategoryVehs22 = [...new Set(currentCategoryVehs.map((vehicle) => {return vehicle}))];
		document.getElementById("mainDivBottomCenterDiv").scrollLeft = 0;
	} else if (name1 === "chooseVeh") {
		if (currentVeh) {
			if (document.getElementById("MDBCDVehicleDiv-" + currentVeh)) {
				document.getElementById("MDBCDVehicleDiv-" + currentVeh).classList.remove("MDBCDVehicleDivActive");
			}
		}
		document.getElementById("confirmDiv").style.display = "none";
		currentVehLabel = name5;
		currentVeh = name2;
		document.getElementById("MDBCDVehicleDiv-" + currentVeh).classList.add("MDBCDVehicleDivActive");
		document.getElementById("vehPrice").innerHTML="$" + formatter.format(Number(name4));
		currentPrice = "$" + formatter.format(Number(name4));
		// document.getElementById("vehClass").innerHTML=name3.charAt(0);
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({action: "chooseVeh", veh: name2}));
		document.getElementById("MDSCarLabelDiv").innerHTML=name2;
		if (currentColor) {
			document.querySelector("#MDSCCDColorDiv-" + currentColor).classList.remove("MDSCCDColorDivActive");
			currentColor = null;
		}
		let stock = Number(name6);
		if (managementState === false) {
			if (stock >= 1) {
				document.getElementById("MDSPaymentDivBottomPayButton1").style.display = "flex";
				document.getElementById("MDSPaymentDivBottomPayButton2").style.display = "flex";
			} else {
				document.getElementById("MDSPaymentDivBottomPayButton1").style.display = "none";
				document.getElementById("MDSPaymentDivBottomPayButton2").style.display = "none";
			}
		}
	} else if (name1 === "changeVehColor") {
		if (currentColor) {
			document.querySelector("#MDSCCDColorDiv-" + currentColor).classList.remove("MDSCCDColorDivActive");
		}
		currentColor = Number(name4);
		document.querySelector("#MDSCCDColorDiv-" + currentColor).classList.add("MDSCCDColorDivActive");
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({action: "changeVehColor", r: Number(name2), g: Number(name3), b: Number(name4)}));
	} else if (name1 === "scrollLeft") {
		document.getElementById("mainDivBottomCenterDiv").scrollLeft -= 35;
	} else if (name1 === "scrollRight") {
		document.getElementById("mainDivBottomCenterDiv").scrollLeft += 35;
	} else if (name1 === "startTestDrive") {
		showroomOpen = false;
		document.getElementById("mainDiv").style.display = "none";
		document.getElementById("confirmDiv").style.display = "none";
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({action: "close", type: "showroom", test: true, model: currentVeh}));
	} else if (name1 === "buyVeh") {
		currentPaymentType = name2;
		$("#confirmDiv").fadeIn().css({display: 'flex'});
		document.getElementById("confirmDivH4").innerHTML=`PURCHASE ${currentPrice}`;
		document.getElementById("confirmSpan").innerHTML=`Are you authorizing payment via ${name2} for the purchase of the ${currentVehLabel} model vehicle for ${currentPrice} dollars? Please confirm with 'Yes' or 'No'.`;
	} else if (name1 === "cancelPurchase") {
		$("#confirmDiv").fadeOut().css({display: 'flex'});
	} else if (name1 === "confirmPurchase") {
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({action: "confirmPurchase", model: currentVeh, paymentType: currentPaymentType, dealershipId: currentDealershipId}));
	} else if (name1 === "selectSpot") {
		if (selectedSpot) {
			document.getElementById("showroomDivBottomLeftDiv-" + selectedSpot).classList.remove("showroomDivBottomLeftDivActive");
		}
		selectedSpot = name2;
		document.getElementById("showroomDivBottomLeftDiv-" + name2).classList.add("showroomDivBottomLeftDivActive");
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({action: "createSpotCam", dealershipId: currentDealershipId, spotId: selectedSpot}));
	} else if (name1 === "selectSpotVehicle") {
		if (selectedSpotVehicle) {
			if (document.getElementById("showroomDivBottomRightDivBottom-" + selectedSpotVehicle)) {
				document.getElementById("showroomDivBottomRightDivBottom-" + selectedSpotVehicle).classList.remove("showroomDivBottomRightDivBottomActive");
			}
		}
		selectedSpotVehicle = name2;
		document.getElementById("showroomDivBottomRightDivBottom-" + name2).classList.add("showroomDivBottomRightDivBottomActive");
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({action: "updateShowroomVehicle", model: selectedSpotVehicle, dealershipId: currentDealershipId, spotId: Number(selectedSpot)}));
	} else if (name1 === "selectSellVehicle") {
		sellMenuOpen = false;
		document.getElementById("sellVehicleDiv").style.display = "none";
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({action: "createTextsOnPlayers", dealershipId: currentDealershipId, model: name2, price: Number(name3)}));
	}
}

document.getElementById("mainDivBottomCenterDiv").addEventListener("wheel", event => {
	var delta = event.deltaY / 2.5;
    var scrollLeft = document.getElementById("mainDivBottomCenterDiv").scrollLeft;
	document.getElementById("mainDivBottomCenterDiv").scrollLeft = scrollLeft + delta;
    event.preventDefault();
});

document.getElementById("MDBSearchInput").addEventListener('input', (e) => {
	const searchData = e.target.value.toLowerCase();
	const filterData = currentCategoryVehs22.filter((vehicle) => {
		return (vehicle.brand.toLocaleLowerCase().includes(searchData) || vehicle.model.toLocaleLowerCase().includes(searchData))
	});
	displayDealershipVehicle(filterData);
});

const displayDealershipVehicle = (vehicles) => {
	document.getElementById("mainDivBottomCenterDiv").innerHTML = vehicles.map((vehicle) => {
		var {spawncode, brand, model, categoryLabel, stock, price, vLabel} = vehicle;
		let divClass = "";
		if (currentVeh === spawncode) {
			divClass = "MDBCDVehicleDivActive";
		}
		let stockText = "In Stock";
		let stockClass = "MDBCDVehicleDivTopRightSide1";
		if (stock === 0 || stock === undefined) {
			stockText = "Out of Stock";
			stockClass = "MDBCDVehicleDivTopRightSide2";
		}
		document.getElementById("mainDivBottomCenterDiv").innerHTML="";
		document.getElementById("mainDivBottomCenterDiv").scrollLeft = 0;
		return (
			`<div class="MDBCDVehicleDiv ${divClass}" id="MDBCDVehicleDiv-${spawncode}" onclick="clFunc('chooseVeh', '${spawncode}', '${categoryLabel}', '${price}', '${vLabel}', '${stock}')">
				<div id="MDBCDVehicleDivTop">
					<div id="MDBCDVehicleDivTopLeftSide">
						<h4>${brand} ${model}</h4>
						<span style="font-family: Gilroy-Regular; color: rgba(255, 255, 255, 0.45); font-size: 0.8vw;">${categoryLabel}</span>
					</div>
					<div class="MDBCDVehicleDivTopRightSide ${stockClass}"><span>${stockText}</span></div>
				</div>
				<img src="https://docs.fivem.net/vehicles/${model}.webp" style="width: 150px; height: 90px;">
				<div id="MDBCDVehicleDivBottom">
					<div class="MDBCDVehicleDivTopRightSide" style="color: rgba(144, 255, 215, 0.77); text-shadow: 0px 0px 4.8px rgba(144, 255, 215, 0.55);"><span>$${price}</span></div>
				</div>
			</div>`
		)
	}).join('');
}

function appendHtml(el, str) {
	var div = document.createElement('div');
	div.innerHTML = str;
	while (div.children.length > 0) {
		el.appendChild(div.children[0]);
	}
}

document.getElementById("mainDivCenter").addEventListener("wheel", zoom, { passive: false });
function zoom(event) {
	event.preventDefault();
	var xhr = new XMLHttpRequest();
	xhr.open("POST", `https://${GetParentResourceName()}/callback`, true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.send(JSON.stringify({action: "nuiFocusEvent"}));
}

document.getElementById("showroomDivTopInput").addEventListener('input', (e) => {
	const searchData = e.target.value.toLowerCase();
	const filterData = showroomVehicles.filter((vehicle) => {
		return (vehicle.name.toLocaleLowerCase().includes(searchData))
	});
	displayShowroomVehicle(filterData);
});

const displayShowroomVehicle = (vehicles) => {
	document.getElementById("showroomDivBottomRight").innerHTML = vehicles.map((vehicle) => {
		var {name, model} = vehicle;
		let divClass = "";
		if (selectedSpotVehicle === model) {
			divClass = "showroomDivBottomRightDivBottomActive";
		}
		return (
			`<div id="showroomDivBottomRightDiv">
				<div id="showroomDivBottomRightDivTop">
					<div id="showroomDivBottomRightDivTopTextDiv"><span>${name}</span></div>
					<img src="https://docs.fivem.net/vehicles/${model}.webp">
				</div>
				<div class="showroomDivBottomRightDivBottom ${divClass}" id="showroomDivBottomRightDivBottom-${model}" onclick="clFunc('selectSpotVehicle', '${model}')"><span>Display</span><div id="showroomDivBottomRightDivBottomChevrons"><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i></div></div>
			</div>`
		)
	}).join('');
}

document.getElementById("showroomDivTopInput2").addEventListener('input', (e) => {
	const searchData = e.target.value.toLowerCase();
	const filterData = showroomVehicles.filter((vehicle) => {
		return (vehicle.name.toLocaleLowerCase().includes(searchData))
	});
	displayShowroomVehicle2(filterData);
});

const displayShowroomVehicle2 = (vehicles) => {
	document.getElementById("showroomDivBottomRight2").innerHTML = vehicles.map((vehicle) => {
		var {name, model, price} = vehicle;
		return (
			`<div id="showroomDivBottomRightDiv">
				<div id="showroomDivBottomRightDivTop">
					<div id="showroomDivBottomRightDivTopTextDiv"><span>${name}</span></div>
					<img src="https://docs.fivem.net/vehicles/${model}.webp">
				</div>
				<div class="showroomDivBottomRightDivBottom" id="showroomDivBottomRightDivBottom-${model}" onclick="clFunc('selectSellVehicle', '${model}', '${price}')"><span>Send Request</span><div id="showroomDivBottomRightDivBottomChevrons"><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i><i class="fal fa-chevron-right"></i></div></div>
			</div>`
		)
	}).join('');
}