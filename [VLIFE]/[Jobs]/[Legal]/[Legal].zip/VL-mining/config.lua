print("^2Jim-Mining ^7v^4"..GetResourceMetadata(GetCurrentResourceName(), 'version', nil):gsub("%.", "^7.^4").."^7 - ^2Mining Script by ^1Jimathy^7")

Loc = {}

Config = {
	Debug = false, -- enable debug mode
	img = "ox_inventory/web/images/", --Set this to the image directory of your inventory script or "nil" if using newer qb-menu

	Lan = "en", -- Pick your language here

	JimShops = true, 		-- Set this to true if using jim-shops

	Inv = "ox",				--"qb" or "ox"
	Menu = "ox",			--"qb" or "ox"
	ProgressBar = "qb",		--"qb" or "ox"
	Notify = "ox",			--"qb" or "ox"

	DrillSound = true,		-- disable drill sounds

	MultiCraft = true,		-- Enable multicraft
	MultiCraftAmounts = { [1], [5], [10], [50] },

	K4MB1Prop = false, -- Enable this to make use of K4MB1's ore props provided with their Mining Cave MLO

	Timings = { -- Time it takes to do things
		["Cracking"] = math.random(9000, 11500),
		["Washing"] = math.random(10000, 12000),
		["Panning"] = math.random(25000, 30000),
		["Pickaxe"] = math.random(15000, 18000),
		["Mining"] = math.random(10000, 15000),
		["Laser"] = math.random(7000, 10000),
		["OreRespawn"] = math.random(55000, 75000),
		["Crafting"] = 5000,
	},

	CrackPool = { -- Rewards from cracking stone
		"carbon",
		"copperore",
		"ironore",
		"ironore",
		"metalscrap",
	},

	WashPool = {	-- Rewards from washing stone
		"goldore",
		"uncut_ruby",
		"uncut_emerald",
		"uncut_diamond",
		"uncut_sapphire",
		"goldore",
	},

	PanPool = {		-- Rewards from panning
		"can",
		"ironore",
		"goldore",
		"ironore",
		"bottle",
		"stone",
		"goldore",
		"plastic",
		"ironore",
		"bottle",
		"silverore",
		"bottle",
		"stone",
		"silverore",
		"ironore",
		"bottle",
		"rubber",
		"metalscrap",
		"ironore",
	},

------------------------------------------------------------
	OreSell = { -- List of ores you can sell to the buyer npc
		"goldingot",
		"silveringot",
		"copperore",
		"ironore",
		"goldore",
		"silverore",
		"carbon",
	},

	SellingPrices = { -- Selling Prices
		['goldore'] = 500,
		['emerald'] = 1000,
		['ruby'] = 3000,
		['diamond'] = 1500,
		['sapphire'] = 700,




		['copperore'] = 15,
		['silverore'] = 10,
		['ironore'] = 10,
		['carbon'] = 10,

		['goldingot'] = 10,
		['silveringot'] = 7,

		['uncut_emerald'] = 10,
		['uncut_ruby'] = 10,
		['uncut_diamond'] = 10,
		['uncut_sapphire'] = 10, 

		

		['diamond_ring'] = 10,
		['emerald_ring'] = 7	,
		['ruby_ring'] = 25,
		['sapphire_ring'] = 50,
		['diamond_ring_silver'] = 80,
		['emerald_ring_silver'] = 90,
		['ruby_ring_silver'] = 28,
		['sapphire_ring_silver'] = 70,

		['diamond_necklace'] = 10,
		['emerald_necklace'] = 70,
		['ruby_necklace'] = 25,
		['sapphire_necklace'] = 50,
		['diamond_necklace_silver'] = 80,
		['emerald_necklace_silver'] = 90,
		['ruby_necklace_silver'] = 28,
		['sapphire_necklace_silver'] = 70,

		['diamond_earring'] = 10,
		['emerald_earring'] = 70,
		['ruby_earring'] = 25,
		['sapphire_earring'] = 50,
		['diamond_earring_silver'] = 80,
		['emerald_earring_silver'] = 90,
		['ruby_earring_silver'] = 28,
		['sapphire_earring_silver'] = 70,

		['gold_ring'] = 50,
		['goldchain'] = 50,
		['goldearring'] = 50,
		['silver_ring'] = 15,
		['silverchain'] = 10,
		['silverearring'] = 10,

	},
------------------------------------------------------------
--Mining Store Items
	Items = {
		label = "Mining Store",  slots = 9,
		items = {
			{ name = "water_bottle", price = 225, amount = 100, info = {}, type = "item", slot = 1, },
			{ name = "sandwich", price = 350, amount = 250, info = {}, type = "item", slot = 2, },
			{ name = "goldpan", price = 10000, amount = 100, info = {}, type = "item", slot = 3, },
			{ name = "pickaxe",	price = 500, amount = 100, info = {}, type = "item", slot = 4, },
			{ name = "miningdrill",	price = 15000, amount = 50, info = {}, type = "item", slot = 5, },
			{ name = "mininglaser",	price = 90000, amount = 5, info = {}, type = "item", slot = 6, },
			{ name = "drillbit", price = 200, amount = 100, info = {}, type = "item", slot = 7, },
		},
	},
}
Crafting = {
	SmeltMenu = {
		{ ["copper"] = { ["copperore"] = 1 }, ['amount'] = 4 },
		{ ["goldingot"] = { ["goldore"] = 1 } },
		{ ["goldingot"] = { ["goldchain_mining"] = 3 } },
		{ ["goldingot"] = { ["gold_ring"] = 4 } },
		{ ["silveringot"] = { ["silverore"] = 1 } },
		{ ["silveringot"] = { ["silverchain"] = 3 } },
		{ ["silveringot"] = { ["silver_ring"] = 4 } },
		{ ["iron"] = { ["ironore"] = 1 } },
		{ ["steel"] = { ["ironore"] = 1, ["carbon"] = 1 } },
		{ ["aluminum"] = { ["can"] = 2, }, ['amount'] = 3 },
		-- { ["glass"] = { ["bottle"] = 2, }, ['amount'] = 2 },
	},
	GemCut = {
		{ ["emerald"] = { ["uncut_emerald"] = 1, } },
		{ ["diamond_mining"] = { ["uncut_diamond"] = 1}, },
		{ ["ruby"] = { ["uncut_ruby"] = 1 }, },
		{ ["sapphire"] = { ["uncut_sapphire"] = 1 }, },
	},
	RingCut = {
		{ ["gold_ring"] = { ["goldingot"] = 1 }, ['amount'] = 3 },
		{ ["silver_ring"] = { ["silveringot"] = 1 }, ['amount'] = 3 },
		{ ["diamond_ring_mining"] = { ["gold_ring"] = 1, ["diamond_mining"] = 1 }, },
		{ ["emerald_ring"] = { ["gold_ring"] = 1, ["emerald"] = 1 }, },
		{ ["ruby_ring"] = { ["gold_ring"] = 1, ["ruby"] = 1 }, },
		{ ["sapphire_ring"] = { ["gold_ring"] = 1, ["sapphire"] = 1 }, },

		{ ["diamond_ring_silver"] = { ["silver_ring"] = 1, ["diamond_mining"] = 1 }, },
		{ ["emerald_ring_silver"] = { ["silver_ring"] = 1, ["emerald"] = 1 }, },
		{ ["ruby_ring_silver"] = { ["silver_ring"] = 1, ["ruby"] = 1 }, },
		{ ["sapphire_ring_silver"] = { ["silver_ring"] = 1, ["sapphire"] = 1 }, },
	},
	NeckCut = {
		{ ["goldchain_mining"] = { ["goldingot"] = 1 }, ['amount'] = 3  },
		{ ["silverchain"] = { ["silveringot"] = 1 }, ['amount'] = 3  },
		{ ["diamond_necklace"] = { ["goldchain_mining"] = 1, ["diamond_mining"] = 1 }, },
		{ ["ruby_necklace"] = { ["goldchain_mining"] = 1, ["ruby"] = 1 }, },
		{ ["sapphire_necklace"] = { ["goldchain_mining"] = 1, ["sapphire"] = 1 }, },
		{ ["emerald_necklace"] = { ["goldchain_mining"] = 1, ["emerald"] = 1 }, },

		{ ["diamond_necklace_silver"] = { ["silverchain"] = 1, ["diamond_mining"] = 1 }, },
		{ ["ruby_necklace_silver"] = { ["silverchain"] = 1, ["ruby"] = 1 }, },
		{ ["sapphire_necklace_silver"] = { ["silverchain"] = 1, ["sapphire"] = 1 }, },
		{ ["emerald_necklace_silver"] = { ["silverchain"] = 1, ["emerald"] = 1 }, },
	},
	EarCut = {
		{ ["goldearring"] = { ["goldingot"] = 1 }, ['amount'] = 3  },
		{ ["silverearring"] = { ["silveringot"] = 1 }, ['amount'] = 3  },
		{ ["diamond_earring"] = { ["goldearring"] = 1, ["diamond_mining"] = 1 }, },
		{ ["ruby_earring"] = { ["goldearring"] = 1, ["ruby"] = 1 }, },
		{ ["sapphire_earring"] = { ["goldearring"] = 1, ["sapphire"] = 1 }, },
		{ ["emerald_earring"] = { ["goldearring"] = 1, ["emerald"] = 1 }, },

		{ ["diamond_earring_silver"] = { ["silverearring"] = 1, ["diamond_mining"] = 1 }, },
		{ ["ruby_earring_silver"] = { ["silverearring"] = 1, ["ruby"] = 1 }, },
		{ ["sapphire_earring_silver"] = { ["silverearring"] = 1, ["sapphire"] = 1 }, },
		{ ["emerald_earring_silver"] = { ["silverearring"] = 1, ["emerald"] = 1 }, },
	},
}
