local QBCore = exports["qb-core"]:GetCoreObject()


------ Weed

CreateThread(function()
	Wait(100)
	exports["qb-target"]:AddBoxZone("methprocess", vector3(1389.8, 3605.94, 38.94), 2.4, 1.2, { --- METH PROCESS
		name = "methprocess",
		heading=20,
		debugPoly = false,
		minZ=37.94,
  		maxZ=39.54,
	}, {
		options = {
			{
				event = "VL-Drug:Process:Meth",
				icon = "fas fa-hammer",
				label = "Process Drug",
				item = "packagedmeth", --Change Me on server.lua
			},
		},
		distance = 2,
	})
end)

RegisterNetEvent("VL-Drug:Process:Meth", function()  
	if exports['qb-inventory']:HasItem('packagedmeth', 1) then
		local player = PlayerPedId() -- Use this so no loop over all the players
		FreezeEntityPosition(player, true)
		QBCore.Functions.Progressbar("drug-meth", "Packing the drug..", 20500, false, true, {
			disableMovement = true,
			disableCarMovement = true,
			disableMouse = false,
			disableCombat = true,
		}, {
			animDict = "anim@amb@clubhouse@tutorial@bkr_tut_ig3@",
			anim = "machinic_loop_mechandplayer",
			flags = 16,
		}, {}, {}, function() -- Done
			FreezeEntityPosition(player, false)
			TriggerServerEvent("VL-drug:AddMeth")
			ClearPedTasksImmediately(player)
		end, function() -- Cancel
			ClearPedTasksImmediately(player)
			FreezeEntityPosition(player, false)
		end)
	else
		QBCore.Functions.Notify('You dont have the required items', 'error')
	end
end)
