local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent('VL-MCarDrug:start')
AddEventHandler('VL-MCarDrug:start', function()
	local _source = source
	local Player = QBCore.Functions.GetPlayer(source)
	local ItemAcetone = Player.Functions.GetItemByName("acetone")
    local ItemLithium = Player.Functions.GetItemByName("lithium")
	local ItemMethlab = Player.Functions.GetItemByName("methlab")
	if ItemAcetone ~= nil and ItemLithium ~= nil and ItemMethlab ~= nil then
		if ItemAcetone.amount >= 5 and ItemLithium.amount >= 2 and ItemMethlab.amount >= 1 then	
			TriggerClientEvent("VL-MCarDrug:startprod", _source)
			Player.Functions.RemoveItem("acetone", 5, false)
			Player.Functions.RemoveItem("lithium", 2, false)
		else
		TriggerClientEvent('VL-MCarDrug:stop', _source)
		TriggerClientEvent('QBCore:Notify', source, "U don't have enough ingredients to cook!", 'error')
		end
	else
	TriggerClientEvent('VL-MCarDrug:stop', _source)
	TriggerClientEvent('QBCore:Notify', source, "You're missing essential ingredients!", 'error')
	end
end)

RegisterServerEvent('VL-MCarDrug:make')
AddEventHandler('VL-MCarDrug:make', function(posx,posy,posz)
	local _source = source
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	if xPlayer.Functions.GetItemByName('methlab') ~= nil then
		if xPlayer.Functions.GetItemByName('methlab').amount >= 1 then	
			local xPlayers = QBCore.Functions.GetPlayers()
			for i=1, #xPlayers, 1 do
				TriggerClientEvent('VL-MCarDrug:smoke',xPlayers[i],posx,posy,posz, 'a') 
			end		
		else
			TriggerClientEvent('VL-MCarDrug:stop', _source)
		end
	else
	TriggerClientEvent('QBCore:Notify', source, "You're missing a lab!", 'error')
	end
end)

RegisterServerEvent('VL-MCarDrug:finish')
AddEventHandler('VL-MCarDrug:finish', function(qualtiy)
	local _source = source
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	local rnd = math.random(-5, 5)
	local amount = math.floor(qualtiy / 8) + rnd
	xPlayer.Functions.AddItem('packagedmeth', amount)
	TriggerClientEvent('inventory:client:ItemBox', _source, QBCore.Shared.Items['packagedmeth'], "add", amount)
end)

RegisterServerEvent('VL-MCarDrug:blow')
AddEventHandler('VL-MCarDrug:blow', function(posx, posy, posz)
	local _source = source
	local xPlayers = QBCore.Functions.GetPlayers()
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	for i=1, #xPlayers, 1 do
		TriggerClientEvent('VL-MCarDrug:blowup', xPlayers[i],posx, posy, posz)
	end
	xPlayer.Functions.RemoveItem('methlab', 1)
end)

