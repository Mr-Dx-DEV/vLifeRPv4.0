local QBCore = exports["qb-core"]:GetCoreObject()

-- Function to send log to Discord via webhook
local function sendDiscordLog(title, description, color)
    local webhookURL = "https://discord.com/api/webhooks/1278272682856808550/tvNexAySw140rxix4n1LBDWyxo8h_G1vktHK11y3tzYFXhQVjJ77MfXmVPiCeqP8YB_t"  -- Replace with your Discord webhook URL
    local embed = {
        {
            ["title"] = title,
            ["description"] = description,
            ["color"] = color,
            ["footer"] = {
                ["text"] = "VL Drug System Logs"
            },
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")  -- Adds current time in ISO format
        }
    }

    PerformHttpRequest(webhookURL, function(err, text, headers) end, 'POST', json.encode({username = "Server Logs", embeds = embed}), {['Content-Type'] = 'application/json'})
end

RegisterServerEvent("VL-drug:AddMeth", function()    -------- Meth Process 
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if not Player then
        TriggerClientEvent('QBCore:Notify', src, "Trying to Spawn Item? Lol nooooo", "error")
        sendDiscordLog("Unauthorized Access Attempt", "**Player ID:** " .. src .. " tried to access the meth process but was not found in the system.", 16711680)
        return
    end

    TriggerEvent("VL-Drug:Process:Meth", Player)

    local item = Player.Functions.GetItemByName('packagedmeth')
    if not item then
        DropPlayer(src, "Trying to Exploit? We dont want to Ban you! So Stop doing this please!")
        sendDiscordLog("Exploit Attempt Detected", "**Player ID:** " .. src .. " tried to exploit the meth process.", 16711680)
        return
    end

    Player.Functions.RemoveItem("packagedmeth", 1) -- Lets take the item
    Player.Functions.AddItem('meth', 1) -- Lets give the item

    sendDiscordLog("Meth Processing", "**Player ID:** " .. src .. " successfully processed meth.", 65280)
end)
