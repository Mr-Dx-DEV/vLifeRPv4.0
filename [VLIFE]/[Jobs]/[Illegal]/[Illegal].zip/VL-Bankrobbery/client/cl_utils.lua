Utils = {}

Utils.AlertCops = function(bankType)
    if GetResourceState('VL-Dispatch') ~= 'started' then return end

    if copsCalled then return end

    copsCalled = true

    if bankType == 'fleeca' then
        exports['VL-Dispatch']:FleecaBankRobbery()
    elseif bankType == 'maze' then
        exports['VL-Dispatch']:FleecaBankRobbery()
    elseif bankType == 'paleto' then
        exports['VL-Dispatch']:PaletoBankRobbery()
    elseif bankType == 'pacific' then
        exports['VL-Dispatch']:PacificBankRobbery()
    end

    CreateThread(function()
        Wait(5 * 60 * 1000)
        copsCalled = false
    end)
end

Utils.Notify = function(message, notifType, timeOut)
    if Shared.Notify == 'qb' then
        if notifType == 'inform' then notifType = 'primary' end
        QBCore.Functions.Notify(message, notifType, timeOut)
    elseif Shared.Notify == 'ox' then
        lib.notify({
            title = Locales['notify_title'],
            description = message,
            duration = timeOut,
            type = notifType,
            position = 'center-right',
        })
    end
end
