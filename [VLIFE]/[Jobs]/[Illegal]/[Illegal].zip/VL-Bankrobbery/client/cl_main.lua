QBCore = exports['qb-core']:GetCoreObject()

copsCalled = false

--- Functions

--- Handles what happens after completing a laptop hack
---@param success bool - Whether the minigame was successfull
---@param bank string - Name of the bank
---@return nil
OnLaptopHackDone = function(success, bank)
    if not success then return end
    Utils.Notify(Locales['bank_hacked'], 'success', 3000)

    if bank == 'Paleto' then
        TriggerServerEvent('VL-BankRob:server:SetOutsideHacked')
    elseif bank == 'Vault' then
        TriggerServerEvent('VL-BankRob:server:SetGoldHacked')
    else
        TriggerServerEvent('VL-BankRob:server:SetBankHacked', bank)
    end

    TriggerServerEvent('qs-smartphone:server:sendNewMail', {
        sender = Locales['mail_sender'],
        subject = bank,
        message = Locales['mail_message'],
        button = {}
    })
end

--- Performs laptop animation for a given bank
---@param bank string - Name of the bank
---@return nil
LaptopAnimation = function(bank)
    if not Shared.Banks[bank] then return end

    lib.requestAnimDict('anim@heists@ornate_bank@hack', 1500)
    lib.requestModel('hei_prop_hst_laptop', 1500)
    lib.requestModel('hei_p_m_bag_var22_arm_s', 1500)
    
    local ped = cache.ped
    local loc = Shared.Banks[bank].laptop

    LocalPlayer.state:set('inv_busy', true, true)

    local targetPosition, targetRotation = (vec3(GetEntityCoords(ped))), vec3(GetEntityRotation(ped))
    
    if not QBCore.Functions.IsWearingGloves() then
        TriggerServerEvent('evidence:server:CreateFingerDrop', targetPosition)
    end

    local animPos = GetAnimInitialOffsetPosition('anim@heists@ornate_bank@hack', 'hack_enter', loc.x, loc.y, loc.z, loc.x, loc.y, loc.z, 0, 2)
    local animPos2 = GetAnimInitialOffsetPosition('anim@heists@ornate_bank@hack', 'hack_loop', loc.x, loc.y, loc.z, loc.x, loc.y, loc.z, 0, 2)
    local animPos3 = GetAnimInitialOffsetPosition('anim@heists@ornate_bank@hack', 'hack_exit', loc.x, loc.y, loc.z, loc.x, loc.y, loc.z, 0, 2)
    FreezeEntityPosition(ped, true)
    SetEntityHeading(ped, loc.w)

    local netScene = NetworkCreateSynchronisedScene(animPos, targetRotation, 2, false, false, 1065353216, 0, 1.3)
    local bag = CreateObject(`hei_p_m_bag_var22_arm_s`, targetPosition, 1, 1, 0)
    local laptop = CreateObject(`hei_prop_hst_laptop`, targetPosition, 1, 1, 0)
    NetworkAddPedToSynchronisedScene(ped, netScene, 'anim@heists@ornate_bank@hack', 'hack_enter', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, netScene, 'anim@heists@ornate_bank@hack', 'hack_enter_bag', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(laptop, netScene, 'anim@heists@ornate_bank@hack', 'hack_enter_laptop', 4.0, -8.0, 1)

    local netScene2 = NetworkCreateSynchronisedScene(animPos2, targetRotation, 2, false, true, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(ped, netScene2, 'anim@heists@ornate_bank@hack', 'hack_loop', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, netScene2, 'anim@heists@ornate_bank@hack', 'hack_loop_bag', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(laptop, netScene2, 'anim@heists@ornate_bank@hack', 'hack_loop_laptop', 4.0, -8.0, 1)

    local netScene3 = NetworkCreateSynchronisedScene(animPos3, targetRotation, 2, false, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(ped, netScene3, 'anim@heists@ornate_bank@hack', 'hack_exit', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, netScene3, 'anim@heists@ornate_bank@hack', 'hack_exit_bag', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(laptop, netScene3, 'anim@heists@ornate_bank@hack', 'hack_exit_laptop', 4.0, -8.0, 1)

    Wait(200)
    NetworkStartSynchronisedScene(netScene)
    Wait(6300)
    NetworkStartSynchronisedScene(netScene2)
    Wait(2000)

    exports['hacking']:OpenHackingGame(Shared.MinigameSettings.laptop[Shared.Banks[bank].type].time, Shared.MinigameSettings.laptop[Shared.Banks[bank].type].blocks, Shared.MinigameSettings.laptop[Shared.Banks[bank].type].amount, function(Success)
        OnLaptopHackDone(Success, bank)
        LocalPlayer.state:set('inv_busy', false, true)
        NetworkStartSynchronisedScene(netScene3)
        Wait(4600)
        NetworkStopSynchronisedScene(netScene3)
        DeleteObject(bag)
        DeleteObject(laptop)
        FreezeEntityPosition(ped, false)
    end)
end

LootTrolly = function(trolly, bank, index)
    local ped = cache.ped
    local moneyModel = `hei_prop_heist_cash_pile`

    if Shared.Banks[bank].trolly[index].type == 'gold' then moneyModel = `ch_prop_gold_bar_01a` end

    local CurrentTrolly = trolly
    local netId = NetworkGetNetworkIdFromEntity(CurrentTrolly)

    local MoneyObject = CreateObject(moneyModel, GetEntityCoords(ped), true)
    SetEntityVisible(MoneyObject, false, false)
    AttachEntityToEntity(MoneyObject, ped, GetPedBoneIndex(ped, 60309), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 0, true)
    local GrabBag = CreateObject(`hei_p_m_bag_var22_arm_s`, GetEntityCoords(ped), true, false, false)
    
    local GrabOne = NetworkCreateSynchronisedScene(GetEntityCoords(CurrentTrolly), GetEntityRotation(CurrentTrolly), 2, false, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(ped, GrabOne, 'anim@heists@ornate_bank@grab_cash', 'intro', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(GrabBag, GrabOne, 'anim@heists@ornate_bank@grab_cash', 'bag_intro', 4.0, -8.0, 1)
    SetPedComponentVariation(ped, 5, 0, 0, 0)
    NetworkStartSynchronisedScene(GrabOne)
    Wait(1500)

    SetEntityVisible(MoneyObject, true, true)
    
    local GrabTwo = NetworkCreateSynchronisedScene(GetEntityCoords(CurrentTrolly), GetEntityRotation(CurrentTrolly), 2, false, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(ped, GrabTwo, 'anim@heists@ornate_bank@grab_cash', 'grab', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(GrabBag, GrabTwo, 'anim@heists@ornate_bank@grab_cash', 'bag_grab', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(CurrentTrolly, GrabTwo, 'anim@heists@ornate_bank@grab_cash', 'cart_cash_dissapear', 4.0, -8.0, 1)
    NetworkStartSynchronisedScene(GrabTwo)
    Wait(37000)

    SetEntityVisible(MoneyObject, false, false)
    
    local GrabThree = NetworkCreateSynchronisedScene(GetEntityCoords(CurrentTrolly), GetEntityRotation(CurrentTrolly), 2, false, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(ped, GrabThree, 'anim@heists@ornate_bank@grab_cash', 'exit', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(GrabBag, GrabThree, 'anim@heists@ornate_bank@grab_cash', 'bag_exit', 4.0, -8.0, 1)
    NetworkStartSynchronisedScene(GrabThree)

    -- Evidence
    if not QBCore.Functions.IsWearingGloves() then
        TriggerServerEvent('evidence:server:CreateFingerDrop', GetEntityCoords(ped))
    end

    -- Reward
    TriggerServerEvent('VL-BankRob:server:TrollyReward', netId, bank, index)
    Wait(1800)

    DeleteEntity(GrabBag)
    DeleteObject(MoneyObject)
end

--- Performs the animation of planting thermite charge for a given bank and given index number
---@param bank string - Name of the bank
---@param index number - Index number of thermite spot
---@return nil
local PlantThermite = function(bank, index)
    TriggerServerEvent('VL-BankRob:server:RemoveThermite')
    lib.requestAnimDict('anim@heists@ornate_bank@thermal_charge')
    lib.requestModel('hei_p_m_bag_var22_arm_s')
    lib.requestNamedPtfxAsset('scr_ornate_heist')

    local ped = cache.ped

    if not QBCore.Functions.IsWearingGloves() then
        TriggerServerEvent('evidence:server:CreateFingerDrop', GetEntityCoords(ped))
    end

    SetEntityHeading(ped, Shared.Banks[bank].thermite[index].coords.w)
    local pos = Shared.Banks[bank].thermite[index].coords.xyz
    Wait(100)

    local rotx, roty, rotz = table.unpack(vec3(GetEntityRotation(cache.ped)))
    local bagscene = NetworkCreateSynchronisedScene(pos.x, pos.y, pos.z, rotx, roty, rotz, 2, false, false, 1065353216, 0, 1.3)
    local bag = CreateObject(`hei_p_m_bag_var22_arm_s`, pos.x, pos.y, pos.z,  true,  true, false)
    SetEntityCollision(bag, false, true)
    local x, y, z = table.unpack(GetEntityCoords(ped))
    local charge = CreateObject(`hei_prop_heist_thermite`, x, y, z + 0.2,  true,  true, true)
    SetEntityCollision(charge, false, true)
    AttachEntityToEntity(charge, ped, GetPedBoneIndex(ped, 28422), 0, 0, 0, 0, 0, 200.0, true, true, false, true, 1, true)
    NetworkAddPedToSynchronisedScene(ped, bagscene, 'anim@heists@ornate_bank@thermal_charge', 'thermal_charge', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, bagscene, 'anim@heists@ornate_bank@thermal_charge', 'bag_thermal_charge', 4.0, -8.0, 1)
    SetPedComponentVariation(ped, 5, 0, 0, 0)

    NetworkStartSynchronisedScene(bagscene)
    Wait(5000)

    DetachEntity(charge, 1, 1)
    FreezeEntityPosition(charge, true)
    DeleteObject(bag)
    NetworkStopSynchronisedScene(bagscene)

    CreateThread(function()
        Wait(15000)
        DeleteEntity(charge)
    end)
end

--- Performs the animation of covering eyes and starts a server synced ptfx for given bank and thermite index, sets door unlocked
---@param bank string - Name of the bank
---@param index number - Index number of thermite spot
---@return nil
local ThermiteEffect = function(bank, index)
    local ped = cache.ped
    lib.requestAnimDict('anim@heists@ornate_bank@thermal_charge')

    Wait(1500)
    TriggerServerEvent('VL-BankRob:server:ThermitePtfx', bank, index)
    Wait(500)

    TaskPlayAnim(ped, 'anim@heists@ornate_bank@thermal_charge', 'cover_eyes_intro', 8.0, 8.0, 1000, 36, 1, 0, 0, 0)
    TaskPlayAnim(ped, 'anim@heists@ornate_bank@thermal_charge', 'cover_eyes_loop', 8.0, 8.0, 3000, 49, 1, 0, 0, 0)
    Wait(25000)

    ClearPedTasks(ped)
    Wait(2000)

    Utils.Notify(Locales['thermite_success'], 'success', 3000)
end

--- Performs the PlantThermite function and starts the minigame for thermite
---@param bank string - Name of the bank
---@param index number - Index number of trolly in a bank
---@return nil
StartThermite = function(bank, index) -- Globally used
    if not Shared.Banks[bank].thermite[index].hit then
        local pos = GetEntityCoords(cache.ped)

        if #(pos - Shared.Banks[bank].thermite[index].coords.xyz) < 2 then
            PlantThermite(bank, index)
            local bankType = Shared.Banks[bank].type

            exports['ps-ui']:Thermite(function(success)
                if success then
                    TriggerServerEvent('VL-BankRob:server:SetThermiteHit', bank, index)
                    ThermiteEffect(bank, index)
                else
                    Utils.Notify(Locales['thermite_failed'], 'error', 3000)
                end
            end, Shared.MinigameSettings.thermite.timetoShow, Shared.MinigameSettings.thermite.grideSize, Shared.MinigameSettings.thermite.incorrectBlocks)
        end
    end
end

-- Events

RegisterNetEvent('VL-BankRob:client:SetBankHacked', function(bank)
    -- Open Door
    local object = GetClosestObjectOfType(Shared.Banks[bank].vaultDoor.coords.x, Shared.Banks[bank].vaultDoor.coords.y, Shared.Banks[bank].vaultDoor.coords.z, 5.0, Shared.Banks[bank].vaultDoor.object, false, false, false)
    if object == 0 then return end

    if bank == 'Paleto' or bank == 'Vault' then
        local heading = Shared.Banks[bank].vaultDoor.closed

        while heading <= Shared.Banks[bank].vaultDoor.open do
            SetEntityHeading(object, heading + 0.5)
            heading += 0.5
            Wait(10)
        end
    else
        local heading = Shared.Banks[bank].vaultDoor.closed

        while heading >= Shared.Banks[bank].vaultDoor.open do
            SetEntityHeading(object, heading - 0.5)
            heading -= 0.5
            Wait(10)
        end
    end

    -- Set state
    Shared.Banks[bank].hacked = true
end)

RegisterNetEvent('VL-BankRob:client:PDClose', function(bank)
    Shared.Banks[bank].policeClose = not Shared.Banks[bank].policeClose

    local object = GetClosestObjectOfType(Shared.Banks[bank].vaultDoor.coords.x, Shared.Banks[bank].vaultDoor.coords.y, Shared.Banks[bank].vaultDoor.coords.z, 5.0, Shared.Banks[bank].vaultDoor.object, false, false, false)
    if object == 0 then return end

    if Shared.Banks[bank].policeClose then -- Close
        if bank == 'Paleto' or bank == 'Vault' then
            local heading = Shared.Banks[bank].vaultDoor.open

            while heading >= Shared.Banks[bank].vaultDoor.closed do
                SetEntityHeading(object, heading - 0.5)
                heading -= 0.5
                Wait(10)
            end
        else
            local heading = Shared.Banks[bank].vaultDoor.open

            while heading <= Shared.Banks[bank].vaultDoor.closed do
                SetEntityHeading(object, heading + 0.5)
                heading += 0.5
                Wait(10)
            end
        end
    else -- Open
        if bank == 'Paleto' or bank == 'Vault' then
            local heading = Shared.Banks[bank].vaultDoor.closed

            while heading <= Shared.Banks[bank].vaultDoor.open do
                SetEntityHeading(object, heading + 0.5)
                heading += 0.5
                Wait(10)
            end
        else
            local heading = Shared.Banks[bank].vaultDoor.closed

            while heading >= Shared.Banks[bank].vaultDoor.open do
                SetEntityHeading(object, heading - 0.5)
                heading -= 0.5
                Wait(10)
            end
        end
    end
end)

RegisterNetEvent('VL-BankRob:client:SetTrollyBusy', function(bank, index)
    Shared.Banks[bank].trolly[index].busy = true
end)

RegisterNetEvent('VL-BankRob:client:SetTrollyTaken', function(bank, index)
    Shared.Banks[bank].trolly[index].taken = true
end)

RegisterNetEvent('VL-BankRob:client:LootLocker', function(data)
    if not currentBank then return end
    
    -- Check drill
    if Shared.Inventory == 'ox_inventory' and exports['ox_inventory']:Search('count', 'drill') == 0 then
        Utils.Notify(Locales['locker_missing_drill'], 'error', 3000)
        return
    elseif Shared.Inventory == 'qb' and not QBCore.Functions.HasItem('drill') then
        Utils.Notify(Locales['locker_missing_drill'], 'error', 3000)
        return
    end
    
    -- If taken or busy return
    if Shared.Banks[data.bank].lockers[data.locker].busy or Shared.Banks[data.bank].lockers[data.locker].taken then
        Utils.Notify(Locales['locker_hit'], 'error', 3000)
        return
    end

    -- Evidence
    local ped = cache.ped
    local pos = GetEntityCoords(ped)
    if not QBCore.Functions.IsWearingGloves() then
        TriggerServerEvent('evidence:server:CreateFingerDrop', pos)
    end

    -- Lights out minigame
    local result = exports['lightsout']:StartLightsOut(Shared.MinigameSettings.lightsOut.grid, Shared.MinigameSettings.lightsOut.maxClicks)
    if not result then
        Utils.Notify(Locales['minigame_failed'], 'error', 3000)
        return
    end

    -- Set Busy
    TriggerServerEvent('VL-BankRob:server:SetLockerBusy', data.bank, data.locker)
    LocalPlayer.state:set('inv_busy', true, true)

    -- Loot trolly animation
    lib.requestAnimDict('anim@heists@fleeca_bank@drilling')
    TaskPlayAnim(ped, 'anim@heists@fleeca_bank@drilling', 'drill_straight_idle' , 3.0, 3.0, -1, 1, 0, false, false, false)
    local DrillObject = CreateObject(`hei_prop_heist_drill`, pos.x, pos.y, pos.z, true, true, true)
    AttachEntityToEntity(DrillObject, ped, GetPedBoneIndex(ped, 57005), 0.14, 0, -0.01, 90.0, -90.0, 180.0, true, true, false, true, 1, true)

    -- STRESS
    local isDrilling = true

    CreateThread(function()
        while isDrilling do
            Wait(10000)
            TriggerServerEvent('hud:server:GainStress', math.random(4, 8))
        end
    end)

    TriggerEvent('Drilling:Start', function(success)
        if success then
            TriggerServerEvent('VL-BankRob:server:LockerReward', data.bank, data.locker)
        else
            Utils.Notify(Locales['locker_failed'], 'error', 3000)
        end

        StopAnimTask(ped, 'anim@heists@fleeca_bank@drilling', 'drill_straight_idle', 1.0)
        DetachEntity(DrillObject, true, true)
        DeleteObject(DrillObject)

        isDrilling = false
        LocalPlayer.state:set('inv_busy', false, true)
        RemoveAnimDict('anim@heists@fleeca_bank@drilling')
    end)
end)

RegisterNetEvent('VL-BankRob:client:SetLockerBusy', function(bank, index)
    Shared.Banks[bank].lockers[index].busy = true
end)

RegisterNetEvent('VL-BankRob:client:SetLockerTaken', function(bank, index)
    Shared.Banks[bank].lockers[index].taken = true
end)

RegisterNetEvent('thermite:UseThermite', function()
    local pos = GetEntityCoords(cache.ped)

    if currentBank and Shared.Banks[currentBank].thermite then
        for i = 1, #Shared.Banks[currentBank].thermite, 1 do
            if #(pos - Shared.Banks[currentBank].thermite[i].coords.xyz) < 2 then
                StartThermite(currentBank, i)
                return
            end
        end
    end
end)

RegisterNetEvent('VL-BankRob:client:ThermitePtfx', function(coords)
    lib.requestNamedPtfxAsset('scr_ornate_heist', 1500)
    SetPtfxAssetNextCall('scr_ornate_heist')
    local effect = StartParticleFxLoopedAtCoord('scr_heist_ornate_thermal_burn', coords, 0.0, 0.0, 0.0, 1.0, false, false, false, false)
    Wait(27500)
    StopParticleFxLooped(effect, 0)
end)

RegisterNetEvent('VL-BankRob:client:SetThermiteHit', function(bank, index)
    Shared.Banks[bank].thermite[index].hit = true
end)

RegisterNetEvent('VL-BankRob:client:ResetBank', function(bank)
    -- Door
    Shared.Banks[bank].hacked = false
    Shared.Banks[bank].policeClose = false

    -- lockers
    for i = 1, #Shared.Banks[bank].lockers, 1 do
        Shared.Banks[bank].lockers[i].busy = false
        Shared.Banks[bank].lockers[i].taken = false
    end

    -- Trollys
    for j = 1, #Shared.Banks[bank].trolly, 1 do
        Shared.Banks[bank].trolly[j].taken = false
    end

    -- Thermite spots
    if Shared.Banks[bank].thermite then
        for k = 1, #Shared.Banks[bank].thermite, 1 do
            Shared.Banks[bank].thermite[k].hit = false
        end
    end

    -- Stackpiles of cash or gold
    if Shared.Banks[bank].stacks then
        for h = 1, #Shared.Banks[bank].stacks, 1 do
            Shared.Banks[bank].stacks[h].busy = false
            Shared.Banks[bank].stacks[h].taken = false
        end
    end

    -- Big Banks
    if bank == 'Paleto' then
        Shared.Banks['Paleto'].outsideHack = false
    elseif bank == 'Pacific' then
        Shared.Banks['Pacific'].card = false
    elseif bank == 'Vault' then
        Shared.Banks['Vault'].lockdown = false
        Shared.Banks['Vault'].goldhacked = false
        Shared.Banks['Vault'].code = false
    end
end)

RegisterNetEvent('VL-BankRob:client:LootTrolly', function(data)
    if not currentBank then return end

    local trolly = data.entity
    local pos = GetEntityCoords(trolly)

    for k, v in pairs(Shared.Banks[currentBank].trolly) do
        if #(pos - v.coords.xyz) < 1.0 then

            -- If taken or busy return
            if v.busy or v.taken then
                Utils.Notify(Locales['trolly_hit'], 'success', 3000)
                return 
            end
            
            -- Set Busy
            TriggerServerEvent('VL-BankRob:server:SetTrollyBusy', currentBank, k)
            LocalPlayer.state:set('inv_busy', true, true)

            -- Loot trolly animation
            LootTrolly(trolly, currentBank, k)
            LocalPlayer.state:set('inv_busy', false, true)

            -- Evidence
            if not QBCore.Functions.IsWearingGloves() then
                TriggerServerEvent('evidence:server:CreateFingerDrop', pos)
            end

            return
        end
    end
end)

CreateThread(function()
    -- Get Shared on startup
    lib.callback('VL-BankRob:server:GetShared', 200, function(result)
        Shared = result
    end)

    -- Target for trollys
    local trollyModels = { `hei_prop_hei_cash_trolly_01`, `ch_prop_gold_trolly_01a` }
    exports['qb-target']:AddTargetModel(trollyModels, {
        options = {
            {
                type = 'client',
                event = 'VL-BankRob:client:LootTrolly',
                icon = 'fas fa-hand-holding',
                label = Locales['trolly_target_label'],
                canInteract = function(entity)
                    return currentBank and Shared.Banks[currentBank].hacked
                end,
            }
        },
        distance = 0.85, 
    })

    -- Target for lockers
    for k, v in pairs(Shared.Banks) do
        for i = 1, #v.lockers do
            exports['qb-target']:AddBoxZone('bankrobbery_locker_' .. k .. i, vector3(v.lockers[i].coords.x, v.lockers[i].coords.y, v.lockers[i].coords.z - 1.0), 0.5, 2.0, {
                name = 'bankrobbery_locker_' .. k .. i,
                heading = v.lockers[i].coords.w,
                debugPoly = Shared.Debug,
                minZ = v.lockers[i].coords.z - 1.0,
                maxZ = v.lockers[i].coords.z + 1.0
             }, {
                options = { 
                    {
                        type = 'client',
                        event = 'VL-BankRob:client:LootLocker',
                        icon = 'fas fa-hand-holding',
                        label = Locales['locker_target_label'],
                        canInteract = function()
                            return Shared.Banks[k].hacked and not Shared.Banks[k].lockers[i].taken and not Shared.Banks[k].lockers[i].busy
                        end,
                        bank = k,
                        locker = i
                    }
                },
                distance = 1.0,
            })
        end
    end

end)
