Rewards = {}

Rewards.Trollys = {
    ['money'] = { -- Amount of bags rewarded when a player loots a trolly, minWorth and maxWorth decide the item.info.worth of the markedbills
        fleeca = { minAmount = 70000, maxAmount = 80000},
        maze = { minAmount = 70000, maxAmount = 70000},
        paleto = { minAmount = 550000, maxAmount = 600000},
        pacific = { minAmount = 700000, maxAmount = 800000},
        vault = { minAmount = 500000, maxAmount = 550000}
    },
    ['gold'] = { -- Amount of gold bars rewarded when a player loots a gold trolly
        fleeca = { minAmount = 8, maxAmount = 10 },
        maze = { minAmount = 9, maxAmount = 11 },
        paleto = { minAmount = 13, maxAmount = 15 },
        pacific = { minAmount = 18, maxAmount = 20 },
        vault = { minAmount = 10, maxAmount = 25 }
    }
}

Rewards.Lockers = {
    ['fleeca'] = {
        items = {'goldbar', }, -- Every time a player unlocks a locker, a random item from this array will be drawn, you can add more items
        amount = { minAmount = 2, maxAmount = 2 },
        rareChance = 15,
        rareItem = 'usb_blue',
    },
    ['maze'] = {
        items = {'goldbar', },
        amount = { minAmount = 10, maxAmount = 12 },
        rareChance = 10,
        rareItem = 'usb_blue',
    },
    ['paleto'] = {
        items = {'goldbar', },
        amount = { minAmount = 4, maxAmount = 4 },
        rareChance = 5,
        rareItem = {'usb_red',}
    },
    ['pacific'] = {
        items = {'goldbar', },
        amount = { minAmount = 10, maxAmount = 14 },
        rareChance = 2,
        rareItem = {'usb_gold',}
    },
    ['vault'] = {
        items = {'goldbar', },
        amount = { minAmount = 10, maxAmount = 14 },
        rareChance = 20,
        rareItem = 'goldbar', -- You could use the vault to drop a rare item used in another heist!
    }
}

Rewards.Stacks = {
    ['money'] = { -- Amount of bags rewarded when a player loots a trolly, minWorth and maxWorth decide the item.info.worth of the markedbills
        fleeca = { minAmount = 2, maxAmount = 3, minWorth = 10000, maxWorth = 14000 },
        maze = { minAmount = 3, maxAmount = 4, minWorth = 10000, maxWorth = 14000 },
        paleto = { minAmount = 4, maxAmount = 5, minWorth = 10000, maxWorth = 14000 },
        pacific = { minAmount = 5, maxAmount = 6, minWorth = 10000, maxWorth = 14000 },
        vault = { minAmount = 500000, maxAmount = 550000}
    },
    ['gold'] = { -- Amount of gold bars rewarded when a player loots a gold trolly
        fleeca = { minAmount = 8, maxAmount = 10 },
        maze = { minAmount = 9, maxAmount = 11 },
        paleto = { minAmount = 10, maxAmount = 12 },
        pacific = { minAmount = 11, maxAmount = 13 },
        vault = { minAmount = 12, maxAmount = 14 }
    }
}
