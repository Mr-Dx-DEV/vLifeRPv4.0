local Framework = require 'framework.server'

-- Function to send log to Discord via webhook
local function sendDiscordLog(title, description, color)
    local webhookURL = "https://discord.com/api/webhooks/1278273167303114884/vjRiF5DixDxkBZvBJBm8O2cYCJy4lpZFnUZ1bSlfcDMOcm5V2pjurHcQo9rv-kWMB3G0"  -- Replace with your Discord webhook URL
    local embed = {
        {
            ["title"] = title,
            ["description"] = description,
            ["color"] = color,
            ["footer"] = {
                ["text"] = "Drug Sales Logs"
            },
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")  -- Adds current time in ISO format
        }
    }

    PerformHttpRequest(webhookURL, function(err, text, headers) end, 'POST', json.encode({username = "Server Logs", embeds = embed}), {['Content-Type'] = 'application/json'})
end

lib.callback.register('VL-CDDrugSell:getCops', function(source)
    return Framework:GetCops() or 0
end)

RegisterNetEvent('VL-CDDrugSell:initiatedrug', function(data)
	local src = source
	local price = data.price * data.amt
	if Config.GiveBonusOnPolice then
		price = Framework:GetCopBonus(price)
	end
	price = math.floor(price)
	local item = tostring(data.item)
	if Framework:RemoveItem(src, item, data.amt) then
		Framework:AddMoney(src, "cash", price)
		TriggerClientEvent('VL-CDDrugSell:notify', src, 'You received $' .. price)

        -- Send a log to Discord when a player sells drugs
        sendDiscordLog("Drug Sale", "**Player ID:** " .. src .. " sold " .. data.amt .. " " .. data.item .. " for $" .. price, 65280)

		if Config.Debug then print('You got ' .. data.amt .. ' ' .. data.item .. ' for $' .. price) end
	else
		TriggerClientEvent('VL-CDDrugSell:notify', src, 'You could not sell ' .. data.item .. ' (not enough item)')

        -- Send a log to Discord when a sale fails due to insufficient items
        sendDiscordLog("Failed Drug Sale", "**Player ID:** " .. src .. " attempted to sell " .. data.item .. " but didn't have enough.", 16711680)
	end
end)
