Config = {}

-- do you want to enable debugging?
Config.Debug = false

-- what framework do you use?
Config.Framework = 'qb' -- 'qb', 'esx'

-- what inventory do you use?
Config.Inventory = 'ox' -- 'qb', 'ps', 'ox'

-- what target do you use?
Config.Target = 'ox' -- 'qb', 'ox' (false: DrawText3D)

-- what radial menu do you use?
Config.Radial = 'qb' -- 'qb', 'ox'

-- what dispatch to use for police alerts?
Config.Dispatch = 'ps' -- 'qb', 'ps', 'moz', 'cd', 'custom'

-- what menu you want to use?
Config.OxMenu = true -- true: Ox Menu, false: Ox Context Menu

-- Minimum cops are required to sell drugs; leave this as 0 if you set Config.GiveBonusOnPolice to true
Config.MinimumCops = 0

-- Give a bonus when selling drugs when a certain number of cops are on. Edit these numbers in Framework > server.lua. By default, it's 1.2 prices for more than 0, 1.5 more for more than 3, and 2.0 for more than 7.
Config.GiveBonusOnPolice = true

-- Allow selling to peds sitting in vehicle
Config.SellPedOnVehicle = false

-- Chance to sell drug
Config.ChanceSell = 90 -- (in %) 
-- Chance to call police
Config.PoliceCallChance = 50 -- (in %) 

-- Random sell amount if [Config.SellAnywhere == true]
Config.RandomSell = { min = 1, max = 3 } -- range: min, max

-- Selling timeout so that the menu doesn't stay forever
Config.SellTimeout = 10 -- (secs) Max time you get to choose your option

-- The below option decides whether the person has to toggle selling in a zone (radialmenu/command) (Recommended: false)
Config.ShouldToggleSelling = false

-- Ped models that you dont want to be sold to
Config.BlacklistPeds = {
    "mp_m_shopkeep_01",
    "s_m_y_ammucity_01",
    "s_m_m_lathandy_01",
    "s_f_y_clubbar_01",
    "ig_talcc",
    "g_f_y_vagos_01",
    "hc_hacker",
    "s_m_m_migrant_01",
}

-- The below option is for you to enable selling anywhere
Config.SellAnywhere = false

-- SellItems to be configured only if [Config.SellAnywhere = true]
Config.SellItems = {
    { item = 'cokebaggy',    price = math.random(1600, 2000) },
    { item = 'weed_bag', price = math.random(1000, 1400) },
    { item = 'meth',         price = math.random(2000, 2400) },
}

-- SellZones will only if [Config.SellAnywhere = false]
Config.SellZones = { -- Sell zones and their drugs
    ['vinewood'] = {
        points = {
            vec3(-663.80639648438, 114.2766418457, 97.0),
            vec3(-660.09497070312, 299.65426635742, 97.0),
            vec3(-546.58837890625, 275.86111450196, 97.0),
            vec3(-542.21002197266, 357.8136291504, 97.0),
            vec3(-519.6430053711, 349.90490722656, 97.0),
            vec3(-512.67572021484, 276.3483581543, 97.0),
            vec3(21.216751098632, 278.6813659668, 97.0),
            vec3(49.785594940186, 339.29946899414, 97.0),
            vec3(108.84923553466, 399.87518310546, 97.0),
            vec3(124.068069458, 384.4684753418, 97.0),
            vec3(92.195236206054, 354.55239868164, 97.0),
            vec3(170.3550567627, 377.32186889648, 97.0),
            vec3(841.11456298828, 199.74020385742, 97.0),
            vec3(530.7640991211, -193.10136413574, 97.0)
        },
        thickness = 80.0,
        randomSellAmount = { min = 1, max = 3 },
        items = {
            { item = 'cokebaggy',    price = math.random(1600, 2000) },
            { item = 'weed_bag', price = math.random(1000, 1400) },
            { item = 'meth',         price = math.random(2000, 2400) },
        }
    },
}
