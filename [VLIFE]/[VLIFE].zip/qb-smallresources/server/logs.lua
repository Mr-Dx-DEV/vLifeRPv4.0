local QBCore = exports['qb-core']:GetCoreObject()

local Webhooks = {
    ['qbjobs'] = 'https://discord.com/api/webhooks/1189175884800868394/xBfY08iS8HIdZpWPG7dO2aLsFcNdXYe4HNBjrjOGW2Fl9Kk8-XdBrT-VjSCSkAGjzmRc',
    ['humanelabs'] = 'https://discord.com/api/webhooks/1189176086668525679/erLm-dBBIPQFiECA1nmMx_25Ro76my5v5bulgbRACi8X9pNH9dBkCK3b2uYUuBq7d8nq',
    ['default'] = 'https://discord.com/api/webhooks/1189239564506759188/CMegiozNzN-Eqm5gvwfIqB7ZDf0yX7zDx2OM6KWVwb72IZkzEWMlLMsiSCCXpGQ6Y1GE',
    ['testwebhook'] = 'https://discord.com/api/webhooks/1189239776071647352/Q9Bs8970Moum2bELusO6DXL7K5iTyJ1Qn2_pEzXCvuVN4fxCIK3QWfWpsiou4Kaau_NP',
    ['playermoney'] = 'https://discord.com/api/webhooks/1189239905709195305/IRY4gXbndkAtRWqMG0528q2Mte84qVcoJ8Hi9fFWXjv-wuK9p58gshGbA66F5CIAePpg',
    ['playerinventory'] = 'https://discord.com/api/webhooks/1189240115713806426/bM7xj88jYlGz2umUNIGVaZSHU6p3YdfzpPni-9FIvMdWkBaRykwUOp_KYkZS9MpdGibP',
    ['robbing'] = 'https://discord.com/api/webhooks/1189240248337707069/6HCkw5ebEBbG9zROB-v7fj-GBS5IGb5Ky5wVn9hVyw1oKC0G157D3d2__cEv-QYBPQ6j',
    ['cuffing'] = 'https://discord.com/api/webhooks/1189240502114074704/dSkbuIsbMQZxe4w7wNdbJfRS_BM0C6Kh4dRJVZxN6IFA6D6Sfk4JeCnmQHtY4NaVIp5Q',
    ['drop'] = 'https://discord.com/api/webhooks/1189240617981706291/dGde7d93kCNvqk6zlzZnsminRGmQxFqp0H9F9ZW2GpBGMJsNbzfsLW9lPU4mVAM4P5X6',
    ['trunk'] = 'https://discord.com/api/webhooks/1189240746092527646/_INUIjES4KRrDC9Jf1rv1QPvXPijBuwt98hsbNVRaaEweL4YB1ruqfSXE-E8RAjXby62',
    ['stash'] = 'https://discord.com/api/webhooks/1189240948811628544/Q286A2OffAiFWO2v9KsoV7v6uf2LnYSeLeMpRFWcOHnMO5X7HVbeJCjGaKJULD_w3mGG',
    ['glovebox'] = 'https://discord.com/api/webhooks/1189241079061549076/0C_uaqTTEDsz7m2Tbva5u6OiUjLTxC__Izp8QhMudY703ekV1vLQp3xjwFwSBprVBB3h',
    ['banking'] = 'https://discord.com/api/webhooks/1189241198725058591/_zVOroMJR5W6eNe0pAe0PsV0o4UinNK2R4_fAUimDwUxU0NQ7C3wp0UlZAyvciHQt86r',
    ['vehicleshop'] = 'https://discord.com/api/webhooks/1189241488949923923/eH6ecvlJL3y_CmdSs3rgk80TmtvVoGd_wDQ-zE4YPdls0Q_dTAMmznwMKO8Y_uumwEBb',
    ['vehicleupgrades'] = 'https://discord.com/api/webhooks/1189241634186080256/KaCoQ2fgVHpk-bm9JvVD5kR1v9wzkWrN2HabPuH7CiwVrhyS2ajOiZQIUgv9ZgyxabrH',
    ['shops'] = 'https://discord.com/api/webhooks/1189241793510903818/K41qGqGhXXKJkOvNhLsmn6_IOmJixnnQYGgSEUp4AGf1SClQwIKrIDqaMKjMiJIrsawy',
    ['dealers'] = 'https://discord.com/api/webhooks/1189241939262963712/FuhhX1oNXwIQiv07-Zc1AX-m_FP3hwxISkBBXxFyfSByXmuIusJ9eUT15wRDGBGeI2im',
    ['storerobbery'] = 'https://discord.com/api/webhooks/1189242086390779964/qJAXmDtlSYkVzth4g3cN4kf0gk4qHO-KwznWNmy5jBFrhl8Mutey_f60nsaTb6mnmFOz',
    ['bankrobbery'] = 'https://discord.com/api/webhooks/1189242211808841859/Z3ACoX-W4SXDq0cy0cJnvefAXtAxur1AF1vGB6zE3d6Jx6Uy6t6QF9up9SYmg6-OXSZI',
    ['powerplants'] = 'https://discord.com/api/webhooks/1189242337050775703/r2owv16bE6vT7BgSYFP3TBMYd0e8NScn24YKa-x_Tu5LfIMqMN5nmZ40m2qqgZ0LI5_e',
    ['death'] = 'https://discord.com/api/webhooks/1189242463806820433/_Y3Ce9m1hLxDgHLv7Atojevzepw_NgnI4NE-a-Yon6C2S4G9ZmJTudo4fUz-gOAqcpOF',
    ['joinleave'] = 'https://discord.com/api/webhooks/1189242612499095572/4YFaqio1DT5YRS2V0nflvejzFHASv52CXOrKNzE_SDXNNxtROo9IVilfhT3lrh7kDiWC',
    ['ooc'] = 'https://discord.com/api/webhooks/1189242740890935497/qnEMLQTtvPtC7JhIn8YtfIunBNm7ob_3ivu_XeAV0C2r5RJjXUNggKzrK9-O0AONyKed',
    ['report'] = 'https://discord.com/api/webhooks/1189242940669837423/izn_0gk2pzqYVFkOV1oEjVbm-6W5o_Z2QaMtFH7DyDSrtf-yrwGMOn5kwyoYf4zvGEuA',
    ['me'] = 'https://discord.com/api/webhooks/1189243079694221372/uwT4scHNsg5imevp2iShWrYclGZtwTUFoirTIASgN2aX1lATeQQWiRHL_r2oqabDrgya',
    ['pmelding'] = 'https://discord.com/api/webhooks/1189243225156894721/2K6jZztS22LvqCJN9Jd8hQoEzS2yNYKgSV_8TB77-0uJaWQxVLF9_nk6RE7dfTkYwyCW',
    ['112'] = 'https://discord.com/api/webhooks/1189243356623142993/zU05VedaqT90zkUXQ6QlicSPFmtZ0zIaTS9FqBW0U0_A0omwokgpCqTZOfTCqHRnR2g5',
    ['bans'] = 'https://discord.com/api/webhooks/1189243483995787370/MV5SUjTxfYfXq5KTJY_aVRSd_qZfN6Ytgc2XS_4of3tbvTfE1A_GySfe_atiYFRRhUA7',
    ['anticheat'] = 'https://discord.com/api/webhooks/1189243614593818654/EzXJyBtUnvEj7zS3U7EIWsBmTUWvaO6zd8CEtpntYuxj_n44Ff_aUiFXBBpaDvlWzGl6',
    ['weather'] = 'https://discord.com/api/webhooks/1189244234449047643/Sk_xSTndgE7pE-iuAAqKXwh7aqmmjfuLPQx5LicsdO0-Fq3V_1qXUawTQqS17hlAV5Fg',
    ['moneysafes'] = 'https://discord.com/api/webhooks/1189244484299526284/uvsGgZNEkjHLBuQ6fJRuZnjIds4y42tFvIjF7N689UPbRL8fwZAEjbbL1xzswKE7Rulr',
    ['bennys'] = 'https://discord.com/api/webhooks/1189245910866214952/UGgmjGu-OKBH1GmmCAGdCTtY_P27UkEYtKLmKgk2y1OcR-tZVPls38dbxJzXHu_oULTn',
    ['bossmenu'] = 'https://discord.com/api/webhooks/1189246220372291727/JwqxWOnhX5bljCZ2LyqnZ7JP6_xTiV4uRPCKPCuE87Ot47w07blh_vn_gpV1Pq81U0CF',
    ['robbery'] = 'https://discord.com/api/webhooks/1189249423654531227/Ons3cl8doZbzAf9htENBycDgGfbWApg4NlTaAaEfL5BTB82fgFbz5QNDCMe0IONmQc7k',
    ['casino'] = 'https://discord.com/api/webhooks/1189249515442667591/0ezAa5PIiqi3XiaIA9nsyZGdgPX_sk5YvGWC_VAJCELnI7kVU3aG6jSdII5q4Tc7_Ph1',
    ['traphouse'] = 'https://discord.com/api/webhooks/1189249599823675452/S7u-b5Vsp4ve0FAQu6vkvZuFOHam_beuf-8St8HjuMYcpTtgxc7ArxdP8o3DJaUiIcr5',
    ['911'] = 'https://discord.com/api/webhooks/1189249845446311996/0FRI5bk3n1XZWUXPm5y7wymMUQMa6EIoKQhYJ8jP1ua3PFPkWuoJJl-btWLPXu2jEOHA',
    ['palert'] = 'https://discord.com/api/webhooks/1189250217321693214/uC85OIuYwK4NheViLXUpS5k9SMHL6ixb15KSllWO3RgdNEENpKJStZqmjUTsvcFSOzSb',
    ['house'] = 'https://discord.com/api/webhooks/1189250602803404850/JOU3mNllp6awY5LVhbUlaPRXwI9np2sgO6O0Yzuj9rOfP8facgcWPJZwX3RVdJmEBO12',
    ['granny'] = 'https://discord.com/api/webhooks/1189256781168386138/Jmd0w0JRJyz5KmZy0xc8JIGiNFtDWjM3yzCvwBiZF4P8xSHRLuH8AP3qFrnPq6XFJth_',
    ['truckrobbery'] = 'https://discord.com/api/webhooks/1189256957408858163/4bKOaprJr1dzTN4ykPYRZvAYAXnK6AHnnAR8gogKBTDBhUTTPcGDcUPzeQu8lYepudYQ',
    ['varheist'] = 'https://discord.com/api/webhooks/1189263982779969586/2451cBF7EzkgQbywmst2svn0h-kBf0Q-MnhKpK3S3EvNJMdxZHAAO8RjGYJv_jq_jdvI',
    ['hunting'] = 'https://discord.com/api/webhooks/1189264776589742130/AI6-MnM0C7GVmq1TRptm3P0Rmf0D74WaaDBOe0zXjb7ErEBCWLVCGSOiN0qSU8u4rsmd',
    ['gamble'] = 'https://discord.com/api/webhooks/1189264575292518410/QBTqtZP_tDsMtqJpp4tTscH9RLmMW9ACY34vLG1WMf4fqCLiUa8zlw3ynpS5i_zaynZC',
    ['scenes'] = 'https://discord.com/api/webhooks/1189264171326509187/q0CISZe0IGssI8BFIM5WCcytLFjQsgleYFOjWBuRsnlqln-pDTXuGlVpV3_QNHmmR5Qp',
    ['gundrop'] = 'https://discord.com/api/webhooks/1189264355141886023/nqky7hzG099ahB_uGXptn83I8JHOxYBcpstRTjHOba5z94z-Ylp5anQjcxl_pVf7P0vs',
    ['gangmenu'] = 'https://discord.com/api/webhooks/1189263077946949642/orziidigZ2cKlqEOpmkkTZ6QcT29qbpXYmU3ZOY1Ajma1JQw-irx0RF9O2G7xTbvmcN-',
    ['warehouse'] = 'https://discord.com/api/webhooks/1189263603661021325/uyhYAXwoSlgDoraV0Kg4_1Xybra5k2SvjC72u4KJZ6DE9S8SmtyJApIVpWdXcc3PXVIt',
    ['pdarmory'] = 'https://discord.com/api/webhooks/1189246704164278322/uMqC--3JE8A8-rLbJ8A-38yuLQYCGp1sDok8Ryz3fX2DcKNGsd7czkMM8cglWB9IvnXZ',
    ['evidence'] = 'https://discord.com/api/webhooks/1189246859408060467/GVeF3Qv-dxGoZfqccqgenVsPgZ5gYHfgWtJcvdOoqm4nS9y1hDEv2sgRAg73quSZ8PDt',
    ['donjewellery'] = '',
    ['eventtrigger'] = 'https://discord.com/api/webhooks/1273370010366246953/JyHcl3jjZ49xza90qKLwuxWVhpqynjrni6VAwyY7UHQ6etwwFuviqHnCBjgPtDrTSdMh',

    
    
    ['spins'] = 'https://discord.com/api/webhooks//TIhhNsFg7i4_gsDHOJkkJmIP10JfUzl_98qfkNqotVdRRZAd9W9tvdLN-se3gcopF_xU',
    
    ['methruns'] = 'https://discord.com/api/webhooks//kj_vjSSj2ldHHQubsXjhwC2sXShfVdy6MPTgG3Rnx8BZsI22RpXXZiBWKhVOUZLXJ_xq',
    ['cadtax'] = 'https://discord.com/api/webhooks//0pvQoANcw5UdilaisfeinaovXhmrTLcJHQY19iLVHR8JnXmm5BKCKCeIh2nlfRTTfs4U',
    ['vendingwithdraw'] = 'https://discord.com/api///thtn_G7LbQDUZaZXlW323db5yh4YTofxqguR6jCYsQFjX9dcuYP6S9yj8SYSo2tHXS4x',
    
    ['EVgrandma'] = 'https://discord.com/api/webhooks//xpmtyhdsas5M-ScYefaq3WdF2_Fp1WLyKMadQYq7VkBtmD9aiAulz0XEkJIhNIn2eLd7',

}

local Colors = { -- https://www.spycolor.com/
    ['default'] = 14423100,
    ['blue'] = 255,
    ['red'] = 16711680,
    ['green'] = 65280,
    ['white'] = 16777215,
    ['black'] = 0,
    ['orange'] = 16744192,
    ['yellow'] = 16776960,
    ['pink'] = 16761035,
    ["lightgreen"] = 65309,
}

local logQueue = {}

RegisterNetEvent('qb-log:server:CreateLog', function(name, title, color, message, tagEveryone)
    local tag = tagEveryone or false
    local webHook = Webhooks[name] or Webhooks['default']
    if tag then
        local embedData = {
            {
                ['title'] = title,
                ['color'] = Colors[color] or Colors['default'],
                ['footer'] = {
                    ['text'] = os.date('%c'),
                },
                ['description'] = message,
                ['author'] = {
                    ['name'] = 'vLifeRP Logs',
                    ['icon_url'] = 'https://cdn.discordapp.com/attachments/1202716897100177539/1206466052717023232/vLifeRP.png?ex=65dc1c12&is=65c9a712&hm=e4c1134657ed1158ce69ebfef31da990bf37b1ef3beca6b073c3f3e2e070aa49&',
                },
            }
        }
        PerformHttpRequest(webHook, function() end, 'POST', json.encode({ username = 'vLifeRP Logs', embeds = embedData}), { ['Content-Type'] = 'application/json' })
        Citizen.Wait(100)
        PerformHttpRequest(webHook, function() end, 'POST', json.encode({ username = 'vLifeRP Logs', content = '@everyone'}), { ['Content-Type'] = 'application/json' })
    else
        local embedData = {
            {
                ['title'] = title,
                ['color'] = Colors[color] or Colors['default'],
                ['footer'] = {
                    ['text'] = os.date('%c'),
                },
                ['description'] = message,
                ['author'] = {
                    ['name'] = 'vLifeRP Logs',
                    ['icon_url'] = 'https://cdn.discordapp.com/attachments/1202716897100177539/1206466052717023232/vLifeRP.png?ex=65dc1c12&is=65c9a712&hm=e4c1134657ed1158ce69ebfef31da990bf37b1ef3beca6b073c3f3e2e070aa49&',
                },
            }
        }

        if not logQueue[name] then logQueue[name] = {} end
        logQueue[name][#logQueue[name]+1] = {webhook = webHook, data = embedData}

        if #logQueue[name] >= 10 then
            local postData = { username = 'vLifeRP Logs', embeds = {} }

            for i = 1, #logQueue[name] do
                postData.embeds[#postData.embeds+1] = logQueue[name][i].data[1]
            end

            PerformHttpRequest(logQueue[name][1].webhook, function() end, 'POST', json.encode(postData), { ['Content-Type'] = 'application/json' })

            logQueue[name] = {}
        end
    end

end)

Citizen.CreateThread(function()
    local timer = 0
    while true do
        Wait(1000)
        timer = timer + 1
        if timer >= 30 then -- If 30 seconds have passed, post the logs
            timer = 0
            for name, queue in pairs(logQueue) do
                if #queue > 0 then
                    local postData = { username = 'vLifeRP Logs', embeds = {} }
                    for i = 1, #queue do
                        postData.embeds[#postData.embeds+1] = queue[i].data[1]
                    end
                    PerformHttpRequest(queue[1].webhook, function() end, 'POST', json.encode(postData), { ['Content-Type'] = 'application/json' })
                    logQueue[name] = {}
                end
            end
        end
    end
end)

QBCore.Commands.Add('testwebhook', 'Test Your Discord Webhook For Logs (God Only)', {}, false, function()
    TriggerEvent('qb-log:server:CreateLog', 'testwebhook', 'Test Webhook', 'default', 'Webhook setup successfully')
end, 'god')