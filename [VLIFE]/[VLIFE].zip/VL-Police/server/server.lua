-----------------For support, scripts, and more----------------
--------------- https://discord.gg/wasabiscripts  -------------
---------------------------------------------------------------
cuffedPlayers, GSRData = {}, {}

local addCommas = function(n)
	return tostring(math.floor(n)):reverse():gsub("(%d%d%d)","%1,")
								  :gsub(",(%-?)$","%1"):reverse()
end

AddEventHandler('playerDropped', function (reason)
    if cuffedPlayers[source] then
        cuffedPlayers[source] = nil
    end
end)

RegisterServerEvent('wasabi_police:setGSR')
AddEventHandler('wasabi_police:setGSR', function(positive)
    GSRData[source] = positive
end)

lib.callback.register('wasabi_police:getPlayerData', function(source, data)
    local newData
    for i=1, #data do
        if not newData then newData = {} end
        newData[#newData + 1] = {
            id = data[i].id,
            name = GetName(data[i].id),
        }
    end
    while not #newData == #data do Wait() end
    return newData
end)

lib.callback.register('wasabi_police:gsrTest', function(source, target)
    if GSRData[target] then return true else return false end
end)