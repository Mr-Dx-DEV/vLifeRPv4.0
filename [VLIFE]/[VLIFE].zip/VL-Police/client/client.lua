-----------------For support, scripts, and more----------------
--------------- https://discord.gg/wasabiscripts  -------------
---------------------------------------------------------------
playerLoaded, isDead, isBusy, disableKeys, cuffProp, isCuffed, inMenu, isRagdoll, cuffTimer, escorting, escorted, GSRData = nil, nil, nil, nil, nil, nil, nil, nil, {}, {}, {}, {}

RegisterNetEvent('wasabi_police:tackled', function(targetId)
    getTackled(targetId)
end)


AddEventHandler('wasabi_police:lockpickVehicle', function()
    local coords = GetEntityCoords(cache.ped)
    local vehicle = lib.getClosestVehicle(vec3(coords.x, coords.y, coords.z), 5.0, false)
    if not vehicle or not DoesEntityExist(vehicle) then
        TriggerEvent('wasabi_police:notify', Strings.vehicle_not_found, Strings.vehicle_not_found_desc, 'error')
    else
        local vehCoords = GetEntityCoords(vehicle)
        local dist = #(vec3(coords.x, coords.y, coords.z) - vec3(vehCoords.x, vehCoords.y, vehCoords.z))
        if dist < 2.5 then
            lockpickVehicle(vehicle)
        else
            TriggerEvent('wasabi_police:notify', Strings.too_far, Strings.too_far_desc, 'error')
        end
    end
end)

AddEventHandler('wasabi_police:impoundVehicle', function()
    local coords = GetEntityCoords(cache.ped)
    local vehicle = lib.getClosestVehicle(vec3(coords.x, coords.y, coords.z), 5.0, false)
    if not vehicle or not DoesEntityExist(vehicle) then
        TriggerEvent('wasabi_police:notify', Strings.vehicle_not_found, Strings.vehicle_not_found_desc, 'error')
    else
        local vehCoords = GetEntityCoords(vehicle)
        local dist = #(vec3(coords.x, coords.y, coords.z) - vec3(vehCoords.x, vehCoords.y, vehCoords.z))
        if dist < 2.5 then
            impoundVehicle(vehicle)
        else
            TriggerEvent('wasabi_police:notify', Strings.too_far, Strings.too_far_desc, 'error')
        end
    end
end)

AddEventHandler('wasabi_police:vehicleInfo', function()
    local coords = GetEntityCoords(cache.ped)
    local vehicle = lib.getClosestVehicle(vec3(coords.x, coords.y, coords.z), 5.0, false)
    if not vehicle or not DoesEntityExist(vehicle) then
        TriggerEvent('wasabi_police:notify', Strings.vehicle_not_found, Strings.vehicle_not_found_desc, 'error')
    else
        local vehCoords = GetEntityCoords(vehicle)
        local dist = #(vec3(coords.x, coords.y, coords.z) - vec3(vehCoords.x, vehCoords.y, vehCoords.z))
        if dist < 3.5 then
            vehicleInfoMenu(vehicle)
        else
            TriggerEvent('wasabi_police:notify', Strings.too_far, Strings.too_far_desc, 'error')
        end
    end
end)

RegisterNetEvent('wasabi_police:takeFromVehicle', function()
	if IsPedSittingInAnyVehicle(cache.ped) then
		local vehicle = GetVehiclePedIsIn(cache.ped, false)
		TaskLeaveVehicle(cache.ped, vehicle, 64)
                FreezeEntityPosition(cache.ped, false)
	end
end)

AddEventHandler('wasabi_police:inVehiclePlayer', function()
    if not HasGroup(Config.policeJobs) then return end
    local coords = GetEntityCoords(cache.ped)
    local player = lib.getClosestPlayer(coords, 4.0, false)
    if not player then
        TriggerEvent('wasabi_police:notify', Strings.no_nearby, Strings.no_nearby_desc, 'error')
    else
        TriggerServerEvent('wasabi_police:inVehiclePlayer', GetPlayerServerId(player))
    end
end)

AddEventHandler('wasabi_police:outVehiclePlayer', function()
    if not HasGroup(Config.policeJobs) then return end
    local coords = GetEntityCoords(cache.ped)
    local player = lib.getClosestPlayer(coords, 4.0, false)
    if not player then
        TriggerEvent('wasabi_police:notify', Strings.no_nearby, Strings.no_nearby_desc, 'error')
    else
        TriggerServerEvent('wasabi_police:outVehiclePlayer', GetPlayerServerId(player))
    end
end)

AddEventHandler('wasabi_police:vehicleInteractions', function()
    vehicleInteractionMenu(vehicle)
end)


AddEventHandler('wasabi_police:checkId', function(targetId)
    if not HasGroup(Config.policeJobs) then return end
    if targetId and type(targetId) == 'table' then targetId = nil end
    if not targetId then
        local coords = GetEntityCoords(cache.ped)
        local player = lib.getClosestPlayer(coords, 4.0, false)
        if not player then
            TriggerEvent('wasabi_police:notify', Strings.no_nearby, Strings.no_nearby_desc, 'error')
        else
            checkPlayerId(GetPlayerServerId(player))
        end
    else
        checkPlayerId(targetId)
    end
end)

AddEventHandler('wasabi_police:revokeLicense', function(data)
    TriggerServerEvent('wasabi_police:revokeLicense', data.targetId, data.license)
    TriggerEvent('wasabi_police:notify', Strings.license_revoked, Strings.license_revoked_desc, 'success')
    Wait(420) -- lul
    checkPlayerId(data.targetId)
end)

AddEventHandler('wasabi_police:manageId', function(data)
    manageId(data)
end)

AddEventHandler('wasabi_police:gsrTest', function()
    GSRTestNearbyPlayer()
end)


-- GSR thread
if Config.GSR.enabled then
    local GSRLoopBreak, GSRLoopRunning, GSRTextUI = false, false , false
    CreateThread(function()
        while true do
            local sleep = 1500
            if IsPedArmed(cache.ped, 4) then
                sleep = 0
                if IsPedShooting(cache.ped) then
                    GSRData.positive = true
                    TriggerServerEvent('wasabi_police:setGSR', true)
                    if Config.GSR.autoClean then
                        GSRData.timer = Config.GSR.autoClean
                        if GSRLoopRunning then GSRLoopBreak = true end
                        CreateThread(function()
                            while GSRData?.positive do
                                if GSRLoopBreak then GSRLoopRunning = false GSRLoopBreak = false break end
                                GSRLoopRunning = true
                                Wait(1000)
                                if GSRData.timer == 0 then
                                    GSRData.positive = nil
                                    TriggerServerEvent('wasabi_police:setGSR', false)
                                else
                                    GSRData.timer = GSRData.timer - 1
                                end
                            end
                        end)
                    end
                end
            elseif Config.GSR.cleanInWater and GSRData?.positive and IsEntityInWater(cache.ped) then
                sleep = 0
                if not GSRTextUI then
                    lib.showTextUI(Strings.gsr_wash_ui)
                    GSRTextUI = true
                end
                if IsControlJustReleased(0, 38) then
                    lib.hideTextUI()
                    if lib.progressCircle({
                        duration = Config.GSR.timeToClean,
                        position = 'bottom',
                        useWhileDead = false,
                        canCancel = true,
                        disable = {
                            car = true,
                            move = true,
                        },
                        anim = {
                            dict = 'missheist_agency3aig_23',
                            clip = 'urinal_sink_loop'
                        },
                    }) then
                        if GSRData?.positive then GSRData.positive = nil end
                        GSRLoopBreak = nil
                        GSRLoopRunning = nil
                        GSRTextUI = false
                        TriggerServerEvent('wasabi_police:setGSR', false)
                        TriggerEvent('wasabi_police:notify', Strings.hands_clean, Strings.hands_clean_desc, 'success')
                    else
                        TriggerEvent('wasabi_police:notify', Strings.cancelled, Strings.cancelled_desc, 'error')
                        GSRTextUI = false
                    end
                end
            elseif GSRTextUI then
                lib.hideTextUI()
                GSRTextUI = false
            end
            Wait(sleep)
        end
    end)
end

-- Main thread
CreateThread(function()
    while PlayerData.job == nil do
        Wait(1000) -- Necessary for some of the loops that use job check in these threads within threads.
    end
    if Config.UseRadialMenu then
        AddRadialItems()
    end
    if Config.useTarget then
        for i=1, #Config.policeJobs do
            local data = {
                targetType = 'Player',
                options = {},
                distance = 2.0
            }
            data.options[#data.options + 1] = {
                num = #data.options + 1,
                event = 'wasabi_police:checkId',
                icon = 'fas fa-id-card',
                label = Strings.check_id,
                job = {["police"] = 0, ["bcso"] = 0}
            }
            data.options[#data.options + 1] = {
                num = #data.options + 1,
                event = 'wasabi_police:gsrTest',
                icon = 'fas fa-magnifying-glass',
                label = 'GRS Test',
                job = {["police"] = 0, ["bcso"] = 0}
            }
            TriggerEvent('wasabi_police:addTarget', data)
        end
    end
end)

-- Spike strip functionality
if Config.spikeStripsEnabled then
    CreateThread(function()
        local spikes = `p_ld_stinger_s`
        while true do
            local sleep = 1500
            local coords = GetEntityCoords(cache.ped)
            local obj = GetClosestObjectOfType(coords.x, coords.y, coords.z, 100.0, spikes, false, false, false)
            if DoesEntityExist(obj) and IsPedInAnyVehicle(cache.ped, false)  then
                sleep = 0
                local vehicle = GetVehiclePedIsIn(cache.ped)
                local objCoords = GetEntityCoords(obj)
                local dist = #(vec3(coords.x, coords.y, coords.z) - vec3(objCoords.x, objCoords.y, objCoords.z))
                if dist < 3.0 then
                    for i=0, 7 do
                        if not IsVehicleTyreBurst(vehicle, i, false) then
                            SetVehicleTyreBurst(vehicle, i, true, 1000)
                        end
                    end
                    sleep = 1500
                end
            end
            Wait(sleep)
        end
    end)
end

if Config.GSR.enabled and Config.GSR.command then
    RegisterCommand(Config.GSR.command, function()
        GSRTestNearbyPlayer()
    end)
end

AddEventHandler('wasabi_police:pdJobMenu', function()
    openJobMenu()
end)

TriggerEvent('chat:removeSuggestion', '/pdJobMenu')

RegisterKeyMapping('pdJobMenu', Strings.key_map_job, 'keyboard', Config.jobMenu)
