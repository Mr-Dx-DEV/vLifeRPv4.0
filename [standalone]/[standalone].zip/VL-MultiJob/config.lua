Config = Config or {}

-- Side of the screen where you want the ui to be on. Can either be "left" or "right"
Config.Side = "right"

-- Config.MaxJobs = 1
Config.IgnoredJobs = {
	["unemployed"] = true,
}

Config.DenyDuty = {
	["ambulance"] = true,
	["police"] = true,
	--["bcso"] = true,
	["doj"] = true,
	["cityhall"] = true,
	["catcafe"] = true,
	--["pizzeria"] = true,
	--["mechanicrsun"] = true,
	--["mechanicamotors"] = true,
	--["mechanical"] = true,
	--["mechanichayes"] = true,
	--["bennys"] = true,
	["countymechanic"] = true,
	["urbanmechanic"] = true,
	["mirror"] = true,
	["henhouse"] = true,
	["upnatom"] = true,
	["beanmachine"] = true,
	["customcaffe"] = true,
	["burgershot"] = true,
	["lplucker"] = true,
	["rexdiner"] = true,
	["hornys"] = true,
	["vanilla"] = true,
	["tropical"] = true,
	["skyclub"] = true,
	["tequilala"] = true,
	["radioshop"] = true,
	--["mechanicredline"] = true,
	["bahamas"] = true,
	["blazeit"] = true,
	["whitewidow"] = true,
	["ppp"] = true,
	["pkart"] = true,
	["costalclove"] = true,
	["koi"] = true,
	["vapeshop"] = true,
	["collectors"] = true,

}

Config.WhitelistJobs = {
	["police"] = true,
	--["bcso"] = true,
	["ambulance"] = true,
	["realestate"] = true,
	["judge"] = true,
	["lawyer"] = true,
	["doj"] = true,
}

Config.Descriptions = {
	["police"] = "Shoot some criminals or maybe be a good cop and arrest them",
	["ambulance"] = "Fix the bullet holes",
	["mechanic"] = "Fix the bullet holes",
	["tow"] = "Pickup the tow truck and steal some vehicles",
	["taxi"] = "Pickup people around the city and drive them to their destination",
	["bus"] = "Pickup multiple people around the city and drive them to their destination",
	["realestate"] = "Sell houses or something",
	["cardealer"] = "Sell cars or something",
	["judge"] = "Decide if people are guilty",
	["doj"] = "Make the PD department life hell.",
	["lawyer"] = "Help the good or the bad",
	["reporter"] = "Lowkey useless",
	["trucker"] = "Drive a truck",
	["garbage"] = "Drive a garbage truck",
	["vineyard"] = "Get them vines",
	["hotdog"] = "Sell them glizzys",
}

-- Change the icons to any free font awesome icon, also add other jobs your server might have to the list
-- List: https://fontawesome.com/search?o=r&s=solid
Config.FontAwesomeIcons = {
	["police"] = "fa-solid fa-handcuffs",
	["ambulance"] = "fa-solid fa-user-doctor",
	["mechanic"] = "fa-solid fa-wrench",
	["tow"] = "fa-solid fa-truck-tow",
	["taxi"] = "fa-solid fa-taxi",
	["bus"] = "fa-solid fa-bus",
	["realestate"] = "fa-solid fa-sign-hanging",
	["cardealer"] = "fa-solid fa-cards",
	["judge"] = "fa-solid fa-gave",
	["doj"] = "fa-solid fa-gavel",
	["lawyer"] = "fa-solid fa-gavel",
	["reporter"] = "fa-solid fa-microphone",
	["trucker"] = "fa-solid fa-truck-front",
	["garbage"] = "fa-solid fa-trash-can",
	["vineyard"] = "fa-solid fa-wine-bottle",
	["hotdog"] = "fa-solid fa-hotdog",
}
